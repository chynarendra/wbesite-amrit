<title><?php echo $__env->yieldContent('page_title',$page_title); ?></title>
<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e($page_title); ?></h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>"><?php echo e(trans('app.dashboard')); ?></a>
                            </li>
                            <li class="breadcrumb-item"><?php echo e($page_title); ?></li>
                            <li class="breadcrumb-item"><?php echo e(trans('app.list')); ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <?php echo $__env->make('backend.message.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="container-fluid">
                <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <div class="card-header" style="text-align:right">
                                            <h3 class="card-title"><?php echo e(trans('app.list')); ?></h3>

                                            <?php

                                            $permission = helperPermission();

                                            $allowEdit = $permission['isEdit'];

                                            ?>
                                            <a href="<?php echo e(URL::previous()); ?>" class="pull-right" data-toggle="tooltip"
                                               title="Add New">
                                                <i class="fa fa-arrow-circle-left fa-2x"></i></a>
                                            <a href="<?php echo e(url('/roles/menu')); ?>" class="pull-right" data-toggle="tooltip"
                                               title="View List">
                                                <i class="fa fa-list fa-2x"></i></a>

                                        </div>
                                        <!-- /.card-header -->
                                        <div class="card-body">
                                            <table id="example2" class="table table-bordered">
                                                <thead>
                                                <tr>
                                                    <th width="10px"><?php echo e(trans('app.sn')); ?></th>
                                                    <th><?php echo e(trans('app.parentMenu')); ?></th>
                                                    <th><?php echo e(trans('app.menuName')); ?></th>
                                                    <th><?php echo e(trans('app.controllerLink')); ?> / <?php echo e(trans('app.menuLink')); ?></th>
                                                    <th class="text-center"><?php echo e(trans('app.icon')); ?></th>
                                                    <th style="width: 30px"
                                                        class="text-centered"><?php echo e(trans('app.status')); ?></th>
                                                    <th class="text-right"><?php echo e(trans('app.order')); ?></th>
                                                    <th width="80px"><?php echo e(trans('app.action')); ?></th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <th scope=row><?php echo e(($menus->currentpage()-1) * $menus->perpage() + $key+1); ?></th>
                                                        <td>
                                                            <?php if(isset($data->parent->menu_name)): ?>

                                                                <label class="badge badge-secondary"> <?php echo e($data->parent->menu_name); ?></label>
                                                            <?php else: ?>
                                                                <label class="badge badge-info">Is a Parent</label>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td><?php echo e($data->menu_name); ?></td>
                                                        <td>
                                                            <?php if($data->menu_controller !=null): ?>
                                                                <?php echo e($data->menu_controller); ?>

                                                                <br>
                                                                <?php echo e($data->menu_link); ?>

                                                            <?php else: ?>
                                                                <label class="badge badge-info"> Parent Menu</label>

                                                            <?php endif; ?>
                                                        </td>

                                                        <td class="text-center">  <i class="<?php echo $data->menu_icon; ?>" aria-hidden="true"></i></td>
                                                        <td>
                                                            <?php if($data->menu_status == '1'): ?>
                                                                <button type="button"
                                                                        class="btn btn-success btn-xs"
                                                                        data-toggle="modal"
                                                                        data-target="#statusModal<?php echo e($key); ?>"
                                                                        title="Click here update  status">
                                                                    <?php echo e(trans('app.active')); ?>

                                                                </button>
                                                            <?php elseif($data->menu_status== '0'): ?>
                                                                <button type="button"
                                                                        class="btn btn-danger btn-xs"
                                                                        data-toggle="modal"
                                                                        data-target="#statusModal<?php echo e($key); ?>"
                                                                        title="Click here update  status">
                                                                    <?php echo e(trans('app.inactive')); ?>

                                                                </button>
                                                            <?php endif; ?>
                                                        </td>
                                                        <!-- status modal start -->
                                                        <div class="modal fade" id="statusModal<?php echo e($key); ?>">
                                                            <div class="modal-dialog modal-sm">
                                                                <div class="modal-content">
                                                                    <div class="modal-header"
                                                                         style="background: #ffc107">
                                                                        <h4 class="modal-title"></h4>
                                                                        <button type="button" class="close"
                                                                                data-dismiss="modal"
                                                                                aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <?php echo Form::open(['method' => 'POST', 'class'=>'inline', 'url'=>['roles/menu/menuControllerChangeStatus/'.$data->id]]); ?>

                                                                    <div class="modal-body">
                                                                        <?php if($data->menu_status == 1): ?>
                                                                            <input type="hidden" name="status" value="0">
                                                                            <p>Are you sure you want to
                                                                                inactive?</p>
                                                                        <?php else: ?>
                                                                            <input type="hidden" name="status" value="1">
                                                                            <p>Are you sure you want to active?</p>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="modal-footer justify-content-center">
                                                                        <button type="submit"
                                                                                class="btn btn-primary">Yes
                                                                        </button> &nbsp; &nbsp;
                                                                        <button type="button"
                                                                                class="btn btn-default"
                                                                                data-dismiss="modal">No
                                                                        </button>
                                                                    </div>
                                                                    <?php echo Form::close(); ?>

                                                                </div>
                                                                <!-- /.modal-content -->
                                                            </div>
                                                            <!-- /.modal-dialog -->
                                                        </div>
                                                        <!-- /.modal -->
                                                        <td class="text-center">
                                                            <?php echo e($data->menu_order); ?>

                                                        </td>
                                                            <td>
                                                                <?php if($allowEdit): ?>
                                                                    <button type="button" class="btn btn-info btn-xs"
                                                                            data-toggle="modal"
                                                                            data-target="#editModal<?php echo e($key); ?>"
                                                                            data-placement="top" title="Edit">
                                                                        <i class="fas fa-pencil-alt"></i>
                                                                    </button>
                                                                <?php endif; ?>
                                                                <!-- Edit Modal Start -->
                                                                    <div class="modal fade" id="editModal<?php echo e($key); ?>">
                                                                        <div class="modal-dialog">
                                                                            <div class="modal-content" style="width: 600px;">
                                                                                <div class="modal-header" style="background: #6c757d">
                                                                                    <h4 class="modal-title"><?php echo e(trans('app.add')); ?></h4>
                                                                                    <button type="button" class="close" data-dismiss="modal"
                                                                                            aria-label="Close">
                                                                                        <span aria-hidden="true">&times;</span>
                                                                                    </button>
                                                                                </div>
                                                                                <div class="modal-body">
                                                                                    <?php echo Form::model($data,['method'=>'PUT','route'=>['menu.update',$data->id]]); ?>

                                                                                    <div class="row">
                                                                                        <div class="form-group col-md-6 <?php echo e(($errors->has('parent_id'))?'has-error':''); ?>">
                                                                                            <label><?php echo e(trans('app.parentMenu')); ?></label> <label
                                                                                                    class="text text-danger"> *</label>
                                                                                            <?php echo e(Form::select('parent_id',$parentList->pluck('menu_name','id'),Request::get('parent_id'),['class'=>'form-control select2','style'=>'width: 100%;','placeholder'=>
                                                                                        'Select Parent Menu'])); ?>


                                                                                            <?php echo $errors->first('user_type_id', '<span class="test text-danger">:message</span>'); ?>

                                                                                        </div>
                                                                                        <div class="form-group col-md-6  <?php echo e(($errors->has('menu_name'))?'has-error':''); ?>">
                                                                                            <label><?php echo e(trans('app.name')); ?></label> <label
                                                                                                    class="text text-danger"> *</label>

                                                                                            <?php echo Form::text('menu_name',null,['class'=>'form-control','placeholder'=>'Enter Menu Name']); ?>

                                                                                            <?php echo $errors->first('menu_name', '<span class="test text-danger">:message</span>'); ?>

                                                                                        </div>
                                                                                        <div class="form-group col-md-6 <?php echo e(($errors->has('login_user_name'))?'has-error':''); ?>">
                                                                                            <label><?php echo e(trans('app.controller')); ?></label> <label
                                                                                                    class="text text-danger"> *</label>

                                                                                            <?php echo Form::text('menu_controller',null,['class'=>'form-control','placeholder'=>'Enter Menu Controller Name']); ?>

                                                                                            <?php echo $errors->first('menu_controller', '<span class="text text-danger">:message</span>'); ?>

                                                                                        </div>
                                                                                        <div class="form-group col-md-6 <?php echo e(($errors->has('menu_link'))?'has-error':''); ?>">
                                                                                            <label><?php echo e(trans('app.menuLink')); ?></label> <label
                                                                                                    class="text text-danger"> *</label>

                                                                                            <?php echo Form::text('menu_link',null,['class'=>'form-control','placeholder'=>'fa fa-users']); ?>

                                                                                            <?php echo $errors->first('menu_link', '<span class="text text-danger">:message</span>'); ?>

                                                                                        </div>
                                                                                        <div class="form-group col-md-6 <?php echo e(($errors->has('menu_icon'))?'has-error':''); ?>">
                                                                                            <label><?php echo e(trans('app.icon')); ?></label> <label
                                                                                                    class="text text-danger"> *</label>

                                                                                            <?php echo Form::text('menu_icon',null,['class'=>'form-control','placeholder'=>'Enter Menu Icon']); ?>

                                                                                            <?php echo $errors->first('menu_icon', '<span class="text text-danger">:message</span>'); ?>

                                                                                        </div>
                                                                                        <div class="form-group col-md-6 <?php echo e(($errors->has('menu_order'))?'has-error':''); ?>">
                                                                                            <label><?php echo e(trans('app.order')); ?></label> <label
                                                                                                    class="text text-danger"> *</label>

                                                                                            <?php echo Form::number('menu_order',null,['class'=>'form-control','min'=>'1']); ?>

                                                                                            <?php echo $errors->first('menu_order', '<span class="text text-danger">:message</span>'); ?>

                                                                                        </div>
                                                                                        <div class="form-group col-md-6">
                                                                                            <label for="status"><?php echo e(trans('app.status')); ?> </label><br>
                                                                                            <div class="icheck-success d-inline">
                                                                                                <input type="radio" id="readio1"
                                                                                                       name="status" value="1"
                                                                                                       checked>
                                                                                                <label for="readio1">
                                                                                                    <?php echo e(trans('app.active')); ?>

                                                                                                </label>
                                                                                            </div>
                                                                                            &nbsp; &nbsp;
                                                                                            <div class="icheck-success d-inline">
                                                                                                <input type="radio" id="readio2"
                                                                                                       name="status"
                                                                                                       value="0">
                                                                                                <label for="readio2">
                                                                                                    <?php echo e(trans('app.inactive')); ?>

                                                                                                </label>
                                                                                            </div>

                                                                                        </div>


                                                                                    </div>


                                                                                    <div class="modal-footer justify-content-center">

                                                                                        <button type="submit"
                                                                                                class="btn btn-primary"><?php echo e(trans('app.save')); ?></button>
                                                                                        &nbsp; &nbsp; &nbsp; &nbsp;
                                                                                        <button type="button" class="btn btn-danger"
                                                                                                data-dismiss="modal">
                                                                                            <?php echo e(trans('app.cancel')); ?>

                                                                                        </button>
                                                                                    </div>
                                                                                    <?php echo Form::close(); ?>

                                                                                </div>
                                                                                <!-- /.modal-content -->
                                                                            </div>
                                                                            <!-- /.modal-dialog -->
                                                                        </div>
                                                                    </div>
                                                                    <!-- /Add Modal End -->
                                                            </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                            <span
                                                    class="float-right"><?php echo e($menus->appends(request()->except('page'))->links()); ?>

                                            </span>
                                        </div>
                                        <!-- /.card-body -->
                                    </div>
                                    <!-- /.card -->
                                </div>

                            <!-- /.col -->
                        </div>
                </div>
                <!-- /.row -->
        </section>
        <!-- /.container-fluid -->
        <!-- /.content -->
    </div>

    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/crm_setup/resources/views/backend/roles/menu.blade.php ENDPATH**/ ?>