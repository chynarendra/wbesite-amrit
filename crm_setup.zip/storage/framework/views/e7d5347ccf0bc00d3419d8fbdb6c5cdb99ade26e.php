<title><?php echo $__env->yieldContent('page_title',$page_title); ?></title>
<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e($page_title); ?></h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>"><?php echo e(trans('app.dashboard')); ?></a>
                            </li>
                            <li class="breadcrumb-item"><a href="<?php echo e(url('users')); ?>"><?php echo e($page_title); ?></a></li>
                            <li class="breadcrumb-item"><?php echo e(trans('app.list')); ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <?php echo $__env->make('backend.message.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header" style="text-align:right">
                                <h3 class="card-title"><?php echo e(trans('app.list')); ?></h3>
                                <?php

                                $permission = helperPermission();

                                $allowEdit = $permission['isEdit'];

                                $allowDelete = $permission['isDelete'];

                                $allowAdd = $permission['isAdd'];

                                ?>
                                <a href="<?php echo e(URL::previous()); ?>" class="pull-right" data-toggle="tooltip"
                                   title="Add New">
                                    <i class="fa fa-arrow-circle-left fa-2x"></i></a>
                                <a href="<?php echo e(url('/users')); ?>" class="pull-right" data-toggle="tooltip"
                                   title="View List">
                                    <i class="fa fa-list fa-2x"></i></a>
                                <?php if($allowAdd): ?>
                                    <a href="" class="pull-right" data-toggle="modal"
                                       data-target="#addModal"
                                       title="Add New">
                                        <i class="fa fa-plus-circle fa-2x"></i></a>
                                <?php endif; ?>


                            </div>
                        </div>
                        <!-- /.card-header -->
                            <div class="card">
                                <div class="card-body">
                                    <table id="example2" class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th width="10px"><?php echo e(trans('app.sn')); ?></th>
                                            <th><?php echo e(trans('app.fullName')); ?> </th>
                                            <th><?php echo e(trans('app.email')); ?> / <?php echo e(trans('app.phone')); ?></th>
                                            <th><?php echo e(trans('app.status')); ?></th>
                                            <th><?php echo e(trans('app.blockStatus')); ?></th>
                                            <th style="width: 70px;"
                                                class="text-right"><?php echo e(trans('app.action')); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope=row><?php echo e(($results->currentpage()-1) * $results->perpage() + $key+1); ?></th>
                                                <td><?php echo e($data->full_name); ?></td>

                                                <td>
                                                    <?php echo e($data->email); ?>

                                                    <?php if(isset($data->phone_number)): ?>
                                                        <br>
                                                        <?php echo e($data->phone_number); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($data->id != \Illuminate\Support\Facades\Auth::user()->id): ?>
                                                        <?php if($data->status == '1'): ?>
                                                            <button type="button"
                                                                    class="btn btn-success btn-xs"
                                                                    data-toggle="modal"
                                                                    data-target="#statusModal<?php echo e($key); ?>"
                                                                    title="Click here update  status">
                                                                <?php echo e(trans('app.active')); ?>

                                                            </button>
                                                        <?php elseif($data->status== '0'): ?>
                                                            <button type="button"
                                                                    class="btn btn-danger btn-xs"
                                                                    data-toggle="modal"
                                                                    data-target="#statusModal<?php echo e($key); ?>"
                                                                    title="Click here update  status">
                                                                <?php echo e(trans('app.inactive')); ?>

                                                            </button>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </td>

                                                <td>
                                                    <?php if($data->id != \Illuminate\Support\Facades\Auth::user()->id): ?>

                                                        <?php if($data->block_status == true): ?>
                                                            <button type="button"
                                                                    class="btn btn-danger btn-xs"
                                                                    data-toggle="modal"
                                                                    data-target="#blockStatusModal<?php echo e($key); ?>"
                                                                    title="Click here update  status">
                                                                <?php echo e(trans('app.yes')); ?>

                                                            </button>

                                                        <?php elseif($data->block_status== false): ?>

                                                            <strong
                                                                    class="btn btn-secondary btn-xs"> <?php echo e(trans('app.no')); ?>

                                                            </strong>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($allowEdit): ?>
                                                        <button type="button" class="btn btn-info btn-xs"
                                                                data-toggle="modal"
                                                                data-target="#editModal<?php echo e($key); ?>"
                                                                data-placement="top" title="Edit">
                                                            <i class="fas fa-pencil-alt"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                    &nbsp;

                                                    <?php if($data->id != \Illuminate\Support\Facades\Auth::user()->id): ?>
                                                        <button type="button" class="btn btn-danger btn-xs"
                                                                data-toggle="modal"
                                                                data-target="#deleteModal<?php echo e($key); ?>"
                                                                data-placement="top" title="Delete">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>

                                            <?php echo $__env->make('backend.modal.status_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <?php echo $__env->make('backend.modal.delete_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <div class="modal fade" id="blockStatusModal<?php echo e($key); ?>">
                                                <div class="modal-dialog modal-sm modal-dialog-centered">
                                                    <div class="modal-content text-center">
                                                        <div class="modal-header btn-secondary">
                                                            <h4 class="modal-title"></h4>
                                                            <button type="button" class="close"
                                                                    data-dismiss="modal"
                                                                    aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <?php echo Form::open(['method' => 'POST', 'class'=>'inline', 'url'=>['users/block_status/'.$data->id]]); ?>

                                                        <div class="modal-body">
                                                            <p>Are you sure you want to unblock?</p>

                                                        </div>
                                                        <div class="modal-footer justify-content-center">
                                                            <button type="submit"
                                                                    class="btn btn-primary">Yes
                                                            </button> &nbsp; &nbsp;
                                                            <button type="button"
                                                                    class="btn btn-default"
                                                                    data-dismiss="modal">No
                                                            </button>
                                                        </div>
                                                        <?php echo Form::close(); ?>

                                                    </div>
                                                    <!-- /.modal-content -->
                                                </div>
                                                <!-- /.modal-dialog -->
                                            </div>




                                            <div class="modal fade" id="editModal<?php echo e($key); ?>">
                                                <div class="modal-dialog">
                                                    <div class="modal-content" style="width: 600px;">
                                                        <div class="modal-header"
                                                             style="background: #6c757d">
                                                            <h4 class="modal-title"><?php echo e(trans('app.edit')); ?></h4>
                                                            <button type="button" class="close"
                                                                    data-dismiss="modal"
                                                                    aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">

                                                            <?php echo Form::model($data,['method'=>'PUT','route'=>['users.update',$data->id],'enctype'=>'multipart/form-data','autocomplete'=>'off']); ?>

                                                            <div class="row">
                                                                <div class="form-group col-md-6 <?php echo e(($errors->has('user_type_id'))?'has-error':''); ?>">
                                                                    <label><?php echo e(trans('app.userType')); ?></label>
                                                                    <label
                                                                            class="text text-danger">
                                                                        *</label>
                                                                    <?php echo e(Form::select('user_type_id',$typeList->pluck('type_name','id'),Request::get('user_type_id'),['class'=>'form-control select2','style'=>'width: 100%;','placeholder'=>
                                                                'Select User Type'])); ?>


                                                                    <?php echo $errors->first('user_type_id', '<span class="text text-danger">:message</span>'); ?>

                                                                </div>
                                                                <div class="form-group col-md-6  <?php echo e(($errors->has('full_name'))?'has-error':''); ?>">
                                                                    <label><?php echo e(trans('app.fullName')); ?></label>
                                                                    <label
                                                                            class="text text-danger">
                                                                        *</label>

                                                                    <?php echo Form::text('full_name',null,['class'=>'form-control','placeholder'=>'Full Name']); ?>

                                                                    <?php echo $errors->first('full_name', '<span class="text text-danger">:message</span>'); ?>

                                                                </div>
                                                                <div class="form-group col-md-6 <?php echo e(($errors->has('login_user_name'))?'has-error':''); ?>">
                                                                    <label><?php echo e(trans('app.loginUser')); ?></label>
                                                                    <label
                                                                            class="text text-danger">
                                                                        *</label>

                                                                    <?php echo Form::text('login_user_name',null,['class'=>'form-control','placeholder'=>'Login User Name']); ?>

                                                                    <?php echo $errors->first('login_user_name', '<span class="text text-danger">:message</span>'); ?>

                                                                </div>
                                                                <div class="form-group col-md-6 <?php echo e(($errors->has('email'))?'has-error':''); ?>">
                                                                    <label><?php echo e(trans('app.loginEmail')); ?></label>
                                                                    <label
                                                                            class="text text-danger">
                                                                        *</label>

                                                                    <?php echo Form::email('email',null,['class'=>'form-control','placeholder'=>'Enter Email Address']); ?>

                                                                    <?php echo $errors->first('email', '<span class="text text-danger">:message</span>'); ?>

                                                                </div>

                                                                <?php if(\Illuminate\Support\Facades\Auth::user()->id != $data->id): ?>
                                                                    <div class="form-group col-md-6">
                                                                        <label for="status"><?php echo e(trans('app.status')); ?> </label><br>
                                                                        <div class="icheck-success d-inline">
                                                                            <input type="radio" id="readio1"
                                                                                   name="status" value="1"
                                                                                   <?php if($data->status=='1'): ?> checked <?php endif; ?>>
                                                                            <label for="readio1">
                                                                                <?php echo e(trans('app.active')); ?>

                                                                            </label>
                                                                        </div>
                                                                        &nbsp; &nbsp;
                                                                        <div class="icheck-success d-inline">
                                                                            <input type="radio" id="readio2"
                                                                                   name="status"
                                                                                   value="0"   <?php if($data->status=='0'): ?> checked <?php endif; ?>>
                                                                            <label for="readio2">
                                                                                <?php echo e(trans('app.inactive')); ?>

                                                                            </label>
                                                                        </div>

                                                                    </div>
                                                                <?php endif; ?>
                                                                <div class="form-group col-md-6">
                                                                    <label for="status"><?php echo e(trans('app.changePassword')); ?> </label><br>
                                                                    <input class="radio-button" type="radio"
                                                                           name="change_password"
                                                                           onclick="changePasswordYes();" value="1"
                                                                           style="margin-top: 2px"> <?php echo e(trans('app.yes')); ?>

                                                                    &nbsp; &nbsp;
                                                                    <input class="radio-button" type="radio"
                                                                           name="change_password"
                                                                           onclick="changePasswordNo()" value="0"
                                                                           style="margin-top: 2px"
                                                                           checked> <?php echo e(trans('app.no')); ?>



                                                                </div>
                                                                <div class="form-group col-md-6 <?php echo e(($errors->has('email'))?'has-error':''); ?>" id="updatePasswordBlock" style="display: none">
                                                                    <label><?php echo e(trans('app.password')); ?></label> <label
                                                                            class="text text-danger"> *</label>

                                                                    <?php echo Form::password('password',array('placeholder'=>'Password','class' => 'form-control'));; ?>


                                                                    <?php echo $errors->first('password', '<span class="text text-danger">:message</span>'); ?>

                                                                </div>
                                                                <div class="form-group col-md-6 <?php echo e(($errors->has('confirm_password'))?'has-error':''); ?>" id="updateConfirmPasswordBlock" style="display: none">
                                                                    <label><?php echo e(trans('app.confirmPassword')); ?></label>
                                                                    <label
                                                                            class="text text-danger"> *</label>

                                                                    <?php echo Form::password('confirm_password',array('placeholder'=>'Confirm Password','class' => 'form-control'));; ?>


                                                                    <?php echo $errors->first('confirm_password', '<span class="text text-danger">:message</span>'); ?>

                                                                </div>
                                                                <div class="form-group col-md-6 <?php echo e(($errors->has('image'))?'has-error':''); ?>">
                                                                    <label for="image"><?php echo e(trans('app.userImage')); ?></label>
                                                                    <input type="file"
                                                                           class="form-control-file"
                                                                           name="image">
                                                                    <?php echo $errors->first('image', '<span class="text text-danger">:message</span>'); ?>


                                                                    <?php if($errors->has('image') == null): ?>
                                                                        <span class="text text-danger"
                                                                              style="font-size: 12px;color: #ff042c">
                                                                                          Note: Upload type should be jpg,jpeg,png  & size less than 1 MB .
                                                                                     </span>
                                                                    <?php endif; ?>
                                                                </div>


                                                            </div>


                                                            <div class="modal-footer justify-content-center">

                                                                <button type="submit"
                                                                        class="btn btn-success"><?php echo e(trans('app.update')); ?></button>
                                                                &nbsp; &nbsp; &nbsp; &nbsp;
                                                                <button type="button" class="btn btn-danger"
                                                                        data-dismiss="modal">
                                                                    <?php echo e(trans('app.cancel')); ?>

                                                                </button>
                                                            </div>
                                                            <?php echo Form::close(); ?>

                                                        </div>
                                                        <!-- /.modal-content -->
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <span class="float-right">
                                        <?php echo e($results->appends(request()->except('page'))->links()); ?>

                                    </span>
                                </div>
                                <!-- /.card-body -->
                            </div>
                            <!-- /.card -->
                    <!-- Add Modal Start -->

                        <div class="modal fade" id="addModal">
                            <div class="modal-dialog">
                                <div class="modal-content" style="width: 600px;">
                                    <div class="modal-header" style="background: #6c757d">
                                        <h4 class="modal-title"><?php echo e(trans('app.add')); ?></h4>
                                        <button type="button" class="close" data-dismiss="modal"
                                                aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">

                                        <?php echo Form::open(['method'=>'post','url'=>'users','enctype'=>'multipart/form-data','autocomplete'=>'off']); ?>

                                        <div class="row">
                                            <div class="form-group col-md-6 <?php echo e(($errors->has('user_type_id'))?'has-error':''); ?>">
                                                <label><?php echo e(trans('app.userType')); ?></label> <label
                                                        class="text text-danger"> *</label>
                                                <?php echo e(Form::select('user_type_id',$typeList->pluck('type_name','id'),Request::get('user_type_id'),['class'=>'form-control select2','style'=>'width: 100%;','placeholder'=>
                                            'Select User Type'])); ?>


                                                <?php echo $errors->first('user_type_id', '<span class="text text-danger">:message</span>'); ?>

                                            </div>
                                            <div class="form-group col-md-6  <?php echo e(($errors->has('full_name'))?'has-error':''); ?>">
                                                <label><?php echo e(trans('app.fullName')); ?></label> <label
                                                        class="text text-danger"> *</label>

                                                <?php echo Form::text('full_name',null,['class'=>'form-control','placeholder'=>'Full Name']); ?>

                                                <?php echo $errors->first('full_name', '<span class="text text-danger">:message</span>'); ?>

                                            </div>
                                            <div class="form-group col-md-6 <?php echo e(($errors->has('login_user_name'))?'has-error':''); ?>">
                                                <label><?php echo e(trans('app.loginUser')); ?></label> <label
                                                        class="text text-danger"> *</label>

                                                <?php echo Form::text('login_user_name',null,['class'=>'form-control','placeholder'=>'Login User Name']); ?>

                                                <?php echo $errors->first('login_user_name', '<span class="text text-danger">:message</span>'); ?>

                                            </div>
                                            <div class="form-group col-md-6 <?php echo e(($errors->has('email'))?'has-error':''); ?>">
                                                <label><?php echo e(trans('app.loginEmail')); ?></label> <label
                                                        class="text text-danger"> *</label>

                                                <?php echo Form::email('email',null,['class'=>'form-control','placeholder'=>'Enter Email Address']); ?>

                                                <?php echo $errors->first('email', '<span class="text text-danger">:message</span>'); ?>

                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="status"><?php echo e(trans('app.status')); ?> </label><br>
                                                <div class="icheck-success d-inline">
                                                    <input type="radio" id="readio3"
                                                           name="status" value="1"
                                                           checked>
                                                    <label for="readio3">
                                                        <?php echo e(trans('app.active')); ?>

                                                    </label>
                                                </div>
                                                &nbsp; &nbsp;
                                                <div class="icheck-success d-inline">
                                                    <input type="radio" id="readio4"
                                                           name="status"
                                                           value="0">
                                                    <label for="readio4">
                                                        <?php echo e(trans('app.inactive')); ?>

                                                    </label>
                                                </div>

                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="status"><?php echo e(trans('app.randPassword')); ?> </label><br>
                                                <input class="radio-button" type="radio" name="rand_password" checked=""
                                                       onclick="passwordYes();" value="1" style="margin-top: 2px"> <?php echo e(trans('app.yes')); ?>

                                                &nbsp; &nbsp;
                                                <input class="radio-button" type="radio" name="rand_password"
                                                       onclick="passwordNo()" value="0" style="margin-top: 2px"> <?php echo e(trans('app.no')); ?>



                                            </div>
                                                <div class="form-group col-md-6 <?php echo e(($errors->has('email'))?'has-error':''); ?>"  id="passwordBlock" style="display: none">
                                                    <label><?php echo e(trans('app.password')); ?></label> <label
                                                            class="text text-danger"> *</label>

                                                    <?php echo Form::password('password',array('placeholder'=>'Password','class' => 'form-control'));; ?>


                                                    <?php echo $errors->first('password', '<span class="text text-danger">:message</span>'); ?>

                                                </div>
                                                <div class="form-group col-md-6 <?php echo e(($errors->has('confirm_password'))?'has-error':''); ?>" id="confirmPasswordBlock" style="display: none">
                                                    <label><?php echo e(trans('app.confirmPassword')); ?></label> <label
                                                            class="text text-danger"> *</label>

                                                    <?php echo Form::password('confirm_password',array('placeholder'=>'Confirm Password','class' => 'form-control'));; ?>


                                                    <?php echo $errors->first('confirm_password', '<span class="text text-danger">:message</span>'); ?>

                                                </div>


                                            <div class="form-group col-md-6">
                                                <label for="status"><?php echo e(trans('Send Email')); ?> </label><br>
                                                <input class="radio-button" type="radio" name="send_email" value="1"
                                                       style="margin-top: 2px"> <?php echo e(trans('app.yes')); ?> &nbsp; &nbsp;
                                                <input class="radio-button" type="radio" name="send_email" value="0"
                                                       style="margin-top: 2px" checked> <?php echo e(trans('app.no')); ?>



                                            </div>
                                            <div class="form-group col-md-6 <?php echo e(($errors->has('image'))?'has-error':''); ?>">

                                                <label for="image"><?php echo e(trans('app.userImage')); ?></label>
                                                <input type="file" class="form-control-file"
                                                       name="image">
                                                <?php echo $errors->first('image', '<span class="text text-danger">:message</span>'); ?>


                                                <?php if($errors->has('image') == null): ?>
                                                    <span class="text text-danger"
                                                          style="font-size: 11px;color: #ff042c"> Upload type should be jpg,jpeg,png  & size less than 1 MB .
                                                 </span>
                                                <?php endif; ?>
                                            </div>

                                        </div>


                                        <div class="modal-footer justify-content-center">

                                            <button type="submit"
                                                    class="btn btn-primary"><?php echo e(trans('app.save')); ?></button>
                                            &nbsp; &nbsp; &nbsp; &nbsp;
                                            <button type="button" class="btn btn-danger"
                                                    data-dismiss="modal">
                                                <?php echo e(trans('app.cancel')); ?>

                                            </button>
                                        </div>
                                        <?php echo Form::close(); ?>

                                    </div>
                                    <!-- /.modal-content -->
                                </div>
                                <!-- /.modal-dialog -->
                            </div>
                        </div>
                            <!-- /Add Modal End -->

                            <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
            </div>
        </section>
        <!-- /.container-fluid -->
        <!-- /.content -->
    </div>

    <!-- /.content-wrapper -->

    <script>
        function passwordYes() {
            $("#passwordBlock").hide();
            $("#confirmPasswordBlock").hide();
        }

        function passwordNo() {
            $("#passwordBlock").show();
            $("#confirmPasswordBlock").show();
        }

        function changePasswordYes() {
            $("#updatePasswordBlock").show();
            $("#updateConfirmPasswordBlock").show();
        }

        function changePasswordNo() {
            $("#updatePasswordBlock").hide();
            $("#updateConfirmPasswordBlock").hide();
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel_new_cms/resources/views/backend/users/index.blade.php ENDPATH**/ ?>