<title><?php echo $__env->yieldContent('page_title',$page_title); ?></title>
<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e($page_title); ?></h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>"> <?php echo e(trans('app.dashboard')); ?></a>
                            </li>
                            <li class="breadcrumb-item"><a href="#"><?php echo e($page_title); ?></a></li>
                            <li class="breadcrumb-item"><?php echo e(trans('app.list')); ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <?php echo $__env->make('backend.message.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header" style="text-align:right">
                                <h3 class="card-title"><?php echo e(trans('app.list')); ?></h3>
                                <?php if(  $request->from_date != null ||  $request->to_date != null ||  $request->mobile != null ||  $request->status != null ): ?>
                                    <strong style="margin-right: 350px;"> Total Customer Count :
                                        <span style="font-size: 16px; color: #007bff;"><?php echo e($totalResult); ?></span>
                                    </strong>
                                <?php endif; ?>
                                <?php
                                $permission = helperPermissionLink(url($page_url . '/' . 'create'), url($page_url));

                                $allowEdit = $permission['isEdit'];

                                $allowDelete = $permission['isDelete'];

                                $allowAdd = $permission['isAdd'];
                                $allowShow = $permission['isShow'];
                                ?>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div id="accordion">
                                        <div class="card-header">
                                            <h4 class="card-title float-right">
                                                <a data-toggle="collapse" data-parent="#accordion" href="#search">
                                                    <i class="fas fa-filter"></i>Filter
                                                </a>
                                            </h4>
                                        </div>
                                        <div id="search"
                                             class="panel-collapse collapse <?php if($request->from_date != null ||  $request->to_date != null ||  $request->status != null ||  $request->mobile != null): ?>show <?php endif; ?>">
                                            <table class="table table-responsive p-0" width="100%">
                                                <form
                                                        action="<?php echo e(url($page_url)); ?>" autocomplete="off">
                                                    <tr>

                                                        <td>
                                                            <?php echo e(Form::select('status',customerStatus(),Request::get('status'),['class'=>'form-control select2','placeholder'=>
                                                            'Select Customer Status'])); ?>


                                                        </td>
                                                        <td>
                                                            <?php echo Form::number('mobile',Request::get('mobile'),['class'=>'form-control','autocomplete'=>'off','width'=>'100%','placeholder'=>
                                                                               trans('Mobile Number')]); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo Form::text('from_date',Request::get('from_date'),['class'=>'form-control','id'=>'from_date','autocomplete'=>'off','width'=>'100%','placeholder'=>
                                                                               trans('From Date'),'readonly']); ?>

                                                        </td>

                                                        <td>
                                                            <?php echo Form::text('to_date',Request::get('to_date'),['class'=>'form-control','id'=>'to_date','autocomplete'=>'off','width'=>'100%','placeholder'
                                                                                =>
                                                                               trans('To Date'),'readonly']); ?>

                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="5"
                                                            class="text-center">
                                                            <button type="submit" class="btn btn-primary"><i
                                                                        class="fa fa-search"></i> <?php echo e(trans('app.filter')); ?>

                                                            </button> &nbsp; &nbsp;
                                                            <a href="<?php echo e(url($page_url)); ?>"
                                                               class="btn btn-default"> <i
                                                                        class="fas  fa-sync-alt"></i> <?php echo e(trans('app.refresh')); ?>

                                                            </a>
                                                            &nbsp; &nbsp;
                                                            <a class="btn btn-danger" data-toggle="collapse"
                                                               data-parent="#accordion" href="#search">
                                                                <span aria-hidden="true">&times;</span> Close
                                                            </a>
                                                        </td>
                                                    </tr>

                                                </form>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.col -->
                            </div>
                            <!-- /.card-header -->
                            <?php if(sizeof($results) > 0): ?>
                                <div class="card-body">
                                    <table id="example2" class="table table-striped table-bordered table-hover">
                                        <thead>
                                        <tr>
                                            <th style="width: 10px"><?php echo e(trans('app.sn')); ?></th>
                                            <th><?php echo e(trans('Personal Details')); ?></th>
                                            <th><?php echo e(trans('Source')); ?></th>
                                            <th><?php echo e(trans('app.status')); ?></th>

                                            <th style="width: 80px"><?php echo e(trans('app.action')); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope=row><?php echo e(($results->currentpage()-1) * $results->perpage() + $key+1); ?></th>
                                                <td>
                                                    <i class="fa fa-user"> </i> <label> Full Name
                                                        : </label> <?php echo e($data->customer_name); ?>

                                                    <br>
                                                    <i class="fa fa-home"> </i> <label>Address
                                                        : </label> <?php echo e($data->address); ?>

                                                    <br>
                                                    <i class="fa fa-phone-alt"> </i> <label>Contact
                                                        Number: </label> <?php echo e($data->contact); ?>

                                                    <br>
                                                    <i class="fa fa-envelope"> </i> <label>Email Address: </label>
                                                    <?php if($data->email !=null): ?>
                                                        <?php echo e($data->email); ?>

                                                    <?php else: ?>
                                                        Not Available
                                                    <?php endif; ?>

                                                </td>
                                                <td>
                                                    <?php if(isset($data->source->name)): ?>
                                                        <?php echo e($data->source->name); ?>

                                                    <?php endif; ?>
                                                </td>

                                                <td>
                                                    <?php if($data->status == '1'): ?>
                                                        <button class="btn btn-danger btn-xs" data-toggle="modal"
                                                                data-target="#updateStatusModal<?php echo e($key); ?>"
                                                                data-placement="top" title="Update Status"
                                                        ><?php echo e(customerStatus($data->status)); ?></button>
                                                    <?php elseif($data->status == '2'): ?>
                                                        <button class="btn btn-secondary btn-xs" data-toggle="modal"
                                                                data-target="#updateStatusModal<?php echo e($key); ?>"
                                                                data-placement="top"
                                                                title="Update Status"><?php echo e(customerStatus($data->status)); ?></button>

                                                    <?php elseif($data->status == '3'): ?>
                                                        <button class="btn btn-success btn-xs" data-toggle="modal"
                                                                data-target="#updateStatusModal<?php echo e($key); ?>"
                                                                data-placement="top"
                                                                title="Update Status"><?php echo e(customerStatus($data->status)); ?></button>
                                                    <?php elseif($data->status == '4'): ?>
                                                        <button class="btn btn-warning btn-xs" data-toggle="modal"
                                                                data-target="#updateStatusModal<?php echo e($key); ?>"
                                                                data-placement="top"
                                                                title="Update Status"><?php echo e(customerStatus($data->status)); ?></button>
                                                    <?php elseif($data->status == '5'): ?>
                                                        <button class="btn btn-primary btn-xs"><?php echo e(customerStatus($data->status)); ?></button>
                                                    <?php endif; ?>
                                                </td>



                                                <td>
                                                    <?php if($allowShow): ?>
                                                        <a href="<?php echo e(route($page_route.'.'.'show',[$data->id])); ?>"
                                                           class="btn btn-secondary btn-xs" data-toggle="tooltip"
                                                           data-placement="top" title="Details">
                                                            <i class="fas fa-eye"></i>
                                                        </a>
                                                    <?php endif; ?>

                                                </td>
                                            </tr>
                                            <?php echo $__env->make('backend.modal.customer_update_status_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <?php echo $__env->make('backend.modal.product_add_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <span class="float-right"><?php echo e($results->appends(request()->except('page'))->links()); ?>

                                </span>
                                </div>
                                <!-- /.card-body -->
                            <?php else: ?>
                                <div class="col-md-12" style="padding-top: 10px">
                                    <label class="form-control badge badge-info"
                                           style="text-align:  center; font-size: 18px;">
                                        <i class="fas fa-ban"></i> No record found yet !.
                                    </label>
                                </div>
                        </div>
                    <?php endif; ?>
                    <!-- /.card -->

                        <!-- /.col -->
                    </div>
                </div>
                <!-- /.row -->
            </div>
        </section>
        <!-- /.container-fluid -->
        <!-- /.content -->

    </div>

    <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/crm_setup/resources/views/backend/customer/customer_followup/index.blade.php ENDPATH**/ ?>