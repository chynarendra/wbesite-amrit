<title><?php echo $__env->yieldContent('page_title',$page_title); ?></title>
<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e($page_title); ?></h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>"> <?php echo e(trans('app.dashboard')); ?></a>
                            </li>
                            <li class="breadcrumb-item"><a href="#"><?php echo e($page_title); ?></a></li>
                            <li class="breadcrumb-item"><?php echo e(trans('app.list')); ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <?php echo $__env->make('backend.message.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header" style="text-align:right">
                                <h3 class="card-title"><?php echo e(trans('app.list')); ?></h3>
                                <?php if($request->source_id!= null ): ?>
                                    <strong style="margin-right: 350px;"> Total Query Count :
                                        <span style="font-size: 16px; color: #007bff;"><?php echo e($totalResult); ?></span>
                                    </strong>
                                <?php endif; ?>
                                <?php
                                $permission = helperPermissionLink(url($page_url . '/' . 'create'), url($page_url));

                                $allowEdit = $permission['isEdit'];

                                $allowDelete = $permission['isDelete'];

                                $allowAdd = $permission['isAdd'];
                                ?>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div id="accordion">
                                        <div class="card-header">
                                            <h4 class="card-title float-right">
                                                <a data-toggle="collapse" data-parent="#accordion" href="#search">
                                                    <i class="fas fa-filter"></i>Filter
                                                </a>
                                            </h4>
                                        </div>
                                        <div id="search"
                                             class="panel-collapse collapse <?php if($request->source_id ): ?>show <?php endif; ?>">
                                            <table class="table table-responsive p-0" width="100%">
                                                <form
                                                        action="<?php echo e(url($page_url)); ?>" autocomplete="off">
                                                    <tr>
                                                        <td>
                                                            <?php echo e(Form::select('source_id',$sourceList->pluck('name','id'),Request::get('source_id'),['class'=>'form-control select2','placeholder'=>
                                                            'Select Source'])); ?>


                                                        </td>

                                                        <td colspan="5"
                                                            class="text-center">
                                                            <button type="submit" class="btn btn-primary"><i
                                                                        class="fa fa-search"></i> <?php echo e(trans('app.filter')); ?>

                                                            </button> &nbsp; &nbsp;
                                                            <a href="<?php echo e(url($page_url)); ?>"
                                                               class="btn btn-default"> <i
                                                                        class="fas  fa-sync-alt"></i> <?php echo e(trans('app.refresh')); ?>

                                                            </a>
                                                            &nbsp; &nbsp;
                                                            <a class="btn btn-danger" data-toggle="collapse"
                                                               data-parent="#accordion" href="#search">
                                                                <span aria-hidden="true">&times;</span> Close
                                                            </a>
                                                        </td>
                                                    </tr>

                                                </form>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.col -->
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example2" class="table table-striped table-bordered table-hover">
                                    <thead>
                                    <tr>
                                        <th style="width: 10px"><?php echo e(trans('app.sn')); ?></th>
                                        <th>Name</th>
                                        <th>Address</th>
                                        <th>Email</th>
                                        <th>Phone No</th>
                                        <th>Query Source</th>
                                        <th>Question</th>
                                        <th style="width: 80px"><?php echo e(trans('app.action')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope=row><?php echo e(($results->currentpage()-1) * $results->perpage() + $key+1); ?></th>
                                            <td><?php echo e($data->name); ?></td>
                                            <td><?php echo e($data->address); ?></td>
                                            <td><?php echo e($data->email); ?></td>
                                            <td><?php echo e($data->ph_no); ?></td>
                                            <td>
                                                <?php if(isset($data->source->name)): ?>
                                                    <?php echo e($data->source->name); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo $data->question; ?></td>
                                            <td>
                                                <?php if($allowEdit): ?>
                                                    <a href="<?php echo e(route($page_route.'.'.'edit',[$data->id])); ?>"
                                                       class="btn btn-info btn-xs" data-toggle="tooltip"
                                                       data-placement="top" title="Edit">
                                                        <i class="fas fa-pencil-alt"></i>
                                                    </a>
                                                <?php endif; ?>
                                                <?php if($allowDelete): ?>
                                                    <button type="button" class="btn btn-danger btn-xs"
                                                            data-toggle="modal"
                                                            data-target="#deleteModal<?php echo e($key); ?>"
                                                            data-placement="top" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                <?php endif; ?>

                                            </td>
                                        </tr>
                                        <?php echo $__env->make('backend.modal.delete_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <span class="float-right"><?php echo e($results->appends(request()->except('page'))->links()); ?>

                                </span>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->

                        <!-- /.col -->
                    </div>
                </div>
                <!-- /.row -->
            </div>
        </section>
        <!-- /.container-fluid -->
        <!-- /.content -->

    </div>

    <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/crm_setup/resources/views/backend/customer/customer_query/index.blade.php ENDPATH**/ ?>