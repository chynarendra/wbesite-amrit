<?php $__env->startSection('content'); ?>
    <?php if(Session::has('success')): ?>
        <div class="alert alert-success">
            <i class="fa fa-check" aria-hidden="true"></i>
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <?php echo e(Session::get('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
        <div class="alert alert-danger">
            <i class="fa fa-times" aria-hidden="true"></i>
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <?php echo e(Session::get('error')); ?>

        </div>
    <?php endif; ?>

    <?php if( $errors->has('login_user_name')): ?>

        <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <?php echo e($errors->first('email')); ?>

            <?php echo e($errors->first('login_user_name')); ?>

        </div>
    <?php endif; ?>
    <?php echo Form::open(['method'=>'post','route'=>'login']); ?>


    <div class="input-group mb-3">
        <?php echo Form::text('identity',null,['class'=>'form-control','placeholder'=>'Username or Email Address','autocomplete'=>'off']); ?>

        <div class="input-group-append">
            <div class="input-group-text">
                <span class="fas fa-user"></span>
            </div>
        </div>
    </div>
    <?php if($errors->has('identity')): ?>
        <div class="input-group mb-3" style="margin-top: -13px;">
            <strong style="color: red"><?php echo e($errors->first('identity')); ?></strong>
        </div>
    <?php endif; ?>
    <div class="input-group mb-3">
        <?php echo Form::password('password',array('placeholder'=>'Password','class' => 'form-control','autocomplete'=>'off'));; ?>

        <div class="input-group-append">
            <div class="input-group-text">
                <span class="fas fa-lock"></span>
            </div>
        </div>
    </div>
    <?php if($errors->has('password')): ?>
        <div class="input-group mb-3" style="margin-top: -13px;">
            <strong style="color: red"><?php echo e($errors->first('password')); ?></strong>
        </div>
    <?php endif; ?>
    <?php if(systemSetting()->login_captcha_required == 1): ?>
        <div class="form-group">
            <div class="captcha">
                <span><?php echo captcha_img(); ?></span>
                &nbsp; &nbsp;
                <button type="button" class="btn btn-info" id="reload" data-toggle="tooltip" title="Refresh Captcha">
                    &#x21bb;
                </button>
            </div>
        </div>
        <div class="form-group <?php echo e(($errors->has('captcha'))?'has-error':''); ?>">
            <input id="captcha" type="text" class="form-control" placeholder="Enter Captcha" name="captcha"
                   autocomplete="off">
        </div>
        <?php if($errors->has('captcha')): ?>
            <div class="input-group mb-3" style="margin-top: -13px;">
                <strong style="color: red"><?php echo e($errors->first('captcha')); ?></strong>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <div class="col-xs-12">
        <button type="submit" class="btn btn-primary btn-block">Sign In</button>
    </div>
    <?php echo Form::close(); ?>

    <br>
    <?php if(systemSetting()->forget_password_required == 1): ?>
    <p class="mb-1">
        <a href="<?php echo e(route('password.request')); ?>">I forgot my password</a>
    </p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/new_success/resources/views/auth/login.blade.php ENDPATH**/ ?>