<title><?php echo $__env->yieldContent('page_title',trans('app.mailSetting')); ?></title>
<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e(trans('app.systemSetting')); ?></h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>"><?php echo e(trans('app.dashboard')); ?></a>
                            </li>
                            <li class="breadcrumb-item"><a href="#"><?php echo e(trans('app.systemSetting')); ?></a></li>
                            <li class="breadcrumb-item"><?php echo e(trans('app.mailSetting')); ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <?php echo $__env->make('backend.message.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header" style="text-align:right">
                                <h3 class="card-title"><?php echo e(trans('app.mailSetting')); ?></h3>


                                <?php

                                $permission = helperPermission();

                                $allowEdit = $permission['isEdit'];

                                $allowDelete = $permission['isDelete'];

                                ?>
                                <a href="<?php echo e(URL::previous()); ?>" class="pull-right" data-toggle="tooltip"
                                   title="Go Back">
                                    <i class="fa fa-arrow-circle-left fa-2x"></i></a>
                                <a href="<?php echo e(url('/systemSetting/mailSetting')); ?>" class="pull-right" data-toggle="tooltip"
                                   title="View List">
                                    <i class="fa fa-list fa-2x"></i></a>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example3" class="table table-bordered">
                                    <thead>
                                    <tr>
                                        <th><?php echo e(trans('app.mailFrom')); ?></th>
                                        <th><?php echo e(trans('app.mailDriver')); ?></th>
                                        <th><?php echo e(trans('app.mailHostName')); ?></th>
                                        <th><?php echo e(trans('app.mailPort')); ?></th>
                                        <th><?php echo e(trans('app.mailUserName')); ?></th>
                                        <th><?php echo e(trans('app.mailPassword')); ?></th>
                                        <th><?php echo e(trans('app.mailEncryption')); ?></th>
                                        <th><?php echo e(trans('app.action')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>
                                            <?php if(isset($result['mail_from_address'])): ?>
                                                <?php echo e($result['mail_from_address']); ?>

                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if(isset($result['mail_driver'])): ?>
                                                <?php echo e($result['mail_driver']); ?>

                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if(isset($result['mail_host_name'])): ?>
                                                <?php echo e($result['mail_host_name']); ?>

                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if(isset($result['mail_port'])): ?>
                                                <?php echo e($result['mail_port']); ?>

                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if(isset($result['mail_user_name'])): ?>
                                                <?php echo e($result['mail_user_name']); ?>

                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if(isset($result['mail_password'])): ?>
                                                <?php echo e($result['mail_password']); ?>

                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if(isset($result['mail_encryption'])): ?>
                                                <?php echo e($result['mail_encryption']); ?>

                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($allowEdit): ?>
                                                <button type="button" class="btn btn-info btn-xs"
                                                        data-toggle="modal"
                                                        data-target="#editModal"
                                                        data-placement="top" title="Edit">
                                                    <i class="fas fa-pencil-alt"></i>
                                                </button>
                                            <?php endif; ?>

                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                                <div class="modal fade" id="editModal">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header btn-secondary">
                                                <h4 class="modal-title"><?php echo e(trans('app.update')); ?></h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true" data-toggle="tooltip" title="Close">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <?php echo Form::model($result,['method'=>'PUT','route'=>[$page_route.'.'.'update',$result['id']],'enctype'=>'multipart/form-data','autocomplete'=>'off']); ?>

                                                <div class="row">
                                                    <div class="form-group col-md-6">
                                                        <label><?php echo e(trans('app.mailFrom')); ?></label> <label
                                                                class="text text-danger"> *</label>

                                                        <?php echo Form::text('mail_from_address',null,['class'=>'form-control','required']); ?>

                                                        <?php echo $errors->first('mail_from_address', '<span class="text text-danger">:message</span>'); ?>

                                                    </div>
                                                    <div class="form-group col-md-6">
                                                        <label><?php echo e(trans('app.mailDriver')); ?></label> <label
                                                                class="text text-danger"> *</label>

                                                        <?php echo Form::text('mail_driver',null,['class'=>'form-control','required']); ?>

                                                        <?php echo $errors->first('mail_driver', '<span class="text text-danger">:message</span>'); ?>

                                                    </div>
                                                    <div class="form-group col-md-6">
                                                        <label><?php echo e(trans('app.mailHostName')); ?></label> <label
                                                                class="text text-danger"> *</label>

                                                        <?php echo Form::text('mail_host_name',null,['class'=>'form-control','required']); ?>

                                                        <?php echo $errors->first('mail_host_name', '<span class="text text-danger">:message</span>'); ?>

                                                    </div>
                                                    <div class="form-group col-md-6">
                                                        <label><?php echo e(trans('app.mailPort')); ?></label> <label
                                                                class="text text-danger"> *</label>

                                                        <?php echo Form::text('mail_port',null,['class'=>'form-control','required']); ?>

                                                        <?php echo $errors->first('mail_port', '<span class="text text-danger">:message</span>'); ?>

                                                    </div>
                                                    <div class="form-group col-md-6">
                                                        <label><?php echo e(trans('app.mailUserName')); ?></label> <label
                                                                class="text text-danger"> *</label>

                                                        <?php echo Form::text('mail_user_name',null,['class'=>'form-control','required']); ?>

                                                        <?php echo $errors->first('mail_user_name', '<span class="text text-danger">:message</span>'); ?>

                                                    </div>
                                                    <div class="form-group col-md-6">
                                                        <label><?php echo e(trans('app.mailPassword')); ?></label> <label
                                                                class="text text-danger"> *</label>

                                                        <?php echo Form::text('mail_password',null,['class'=>'form-control','required']); ?>

                                                        <?php echo $errors->first('mail_password', '<span class="text text-danger">:message</span>'); ?>

                                                    </div>
                                                    <div class="form-group col-md-6">
                                                        <label><?php echo e(trans('app.mailEncryption')); ?></label> <label
                                                                class="text text-danger"> *</label>

                                                        <?php echo Form::text('mail_encryption',null,['class'=>'form-control','required']); ?>

                                                        <?php echo $errors->first('mail_encryption', '<span class="text text-danger">:message</span>'); ?>

                                                    </div>
                                                </div>

                                                <div class="modal-footer justify-content-center">

                                                    <button type="submit"
                                                            class="btn btn-success"><?php echo e(trans('app.update')); ?></button>
                                                    &nbsp; &nbsp; &nbsp; &nbsp;
                                                    <button type="button" class="btn btn-danger"
                                                            data-dismiss="modal">
                                                        <?php echo e(trans('app.cancel')); ?>

                                                    </button>
                                                </div>

                                                <?php echo Form::close(); ?>

                                            </div>
                                        </div>
                                        <!-- /.modal-content -->
                                    </div>
                                    <!-- /.modal-dialog -->
                                </div>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->

                        <!-- /.col -->
                    </div>
                </div>
                <!-- /.row -->
            </div>
        </section>
        <!-- /.container-fluid -->
        <!-- /.content -->

    </div>

    <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/api_setup/resources/views/backend/systemSetting/emailSetting.blade.php ENDPATH**/ ?>