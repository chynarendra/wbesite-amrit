<div class="modal fade" id="updateStatusModal<?php echo e($key); ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header btn-info">
                <h4 class="modal-title"><?php echo e(trans('Are you sure you want to update status?')); ?></h4>
                <button type="button" class="close" data-dismiss="modal"
                        aria-label="Close">
                    <span aria-hidden="true" data-toggle="tooltip" title="Close">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <?php
                        $updateStatusList = '';
                        $updateStatusList = \Illuminate\Support\Facades\DB::table('customer_status')
                            ->where('id', '<>', $data->status)
                            ->get();
                        ?>

                        <?php echo Form::open(['method'=>'post','url'=>'customerUpdateStatus']); ?>

                        <input type="hidden" name="customer_id" value="<?php echo e($data->id); ?>">
                        <div class="form-group">
                            <label for="inputName"><?php echo e(trans('Status Name')); ?></label> <label class="text-danger">*</label>
                            <?php echo Form::select('status_id',$updateStatusList->pluck('name','id'),null,['style' => 'width:100%','class'=>'form-control select2','id'=>'status_id','placeholder'=>'Please Select Status','required']); ?>


                            <?php echo $errors->first('name', '<small class="text text-danger">:message</small>'); ?>

                        </div>

                        <div class="form-group <?php echo e(($errors->has('details'))?'has-error':''); ?>" id="follow_up_date" style="display:block;">
                            <label for="inputDescription"><?php echo e(trans('Follow Up Date')); ?></label>
                            <?php echo e(Form::text('followup_date',null,['placeholder'=>' Followup Date','id'=>'follow_date','autocomplete'=>'off','class' => 'form-control followDate','readonly'])); ?>

                            <?php echo $errors->first('followup_date', '<span class="text-danger">:message</span>'); ?>

                        </div>
                        <div  id="product_form" style="display: none">
                            <hr>
                            <div class="form-group col-md-12">
                                <h3  class="text text-primary" style="font-size: 18px; text-align: center"> <?php echo e(trans('Product Add Area')); ?></h3>
                            </div>
                            <div class="form-group col-md-12">
                                <label>Product</label> <label class="text-danger">*</label>
                                <div class="select2-blue">
                                    <select class="select2" multiple="multiple" data-placeholder="Select Products"  name="product_id[]"  id="addProduct"  style="width: 100%; height: 200px;" autocomplete="off">
                                        <?php $__currentLoopData = $productList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option class='form control' value='<?php echo e($data->id); ?>'  <?php echo e(old('product_id') == $data->id ? "selected" :""); ?> >
                                                <?php echo e($data->product_name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                        </div>
                        <hr/>
                        <div class="form-group <?php echo e(($errors->has('remarks'))?'has-error':''); ?>">
                            <label for="inputDescription"><?php echo e(trans('app.details')); ?></label>
                            <?php echo Form::textarea('remarks',null,['class'=>'form-control','placeholder'=>'Enter  Remarks','rows'=>'4','autocomplete'=>'off']); ?>

                            <?php echo $errors->first('remarks', '<span class="label label-danger">:message</span>'); ?>

                        </div>


                        <div class="modal-footer justify-content-center">

                            <button type="submit"
                                    class="btn btn-success"><?php echo e(trans('app.update')); ?></button>
                            &nbsp; &nbsp;
                            <button type="button" class="btn btn-danger"
                                    data-dismiss="modal">
                                <?php echo e(trans('app.cancel')); ?>

                            </button>
                        </div>
                        <?php echo Form::close(); ?>


                    </div>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div><?php /**PATH /var/www/html/crm_setup/resources/views/backend/modal/customer_update_status_modal.blade.php ENDPATH**/ ?>