<title><?php echo $__env->yieldContent('page_title',$page_title); ?></title>
<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e($page_title); ?></h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>"> <?php echo e(trans('app.dashboard')); ?></a>
                            </li>
                            <li class="breadcrumb-item"><a href="#"><?php echo e($page_title); ?></a></li>
                            <li class="breadcrumb-item"><?php echo e(trans('app.list')); ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <?php echo $__env->make('backend.message.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header" style="text-align:right">
                                <h3 class="card-title"><?php echo e(trans('app.list')); ?></h3>
                                <?php if($request->city_id != null ||  $request->from_date != null ||  $request->to_date != null): ?>
                                    <strong style="margin-right: 350px;"> Total Campaign Count :
                                        <span style="font-size: 16px; color: #007bff;"><?php echo e($totalResult); ?></span>
                                    </strong>
                                <?php endif; ?>


                                <?php

                                $permission = helperPermission();

                                $allowEdit = $permission['isEdit'];

                                $allowDelete = $permission['isDelete'];

                                $allowAdd = $permission['isAdd'];

                                ?>
                                <a href="<?php echo e(URL::previous()); ?>" class="pull-right" data-toggle="tooltip"
                                   title="Add New">
                                    <i class="fa fa-arrow-circle-left fa-2x"></i></a>
                                <a href="<?php echo e(url($page_url)); ?>" class="pull-right" data-toggle="tooltip"
                                   title="View List">
                                    <i class="fa fa-list fa-2x"></i></a>
                                <?php if($allowAdd): ?>
                                    <a href="" class="pull-right" data-toggle="modal"
                                       data-target="#addModal"
                                       title="Add New">
                                        <i class="fa fa-plus-circle fa-2x"></i></a>
                                <?php endif; ?>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div id="accordion">
                                        <div class="card-header">
                                            <h4 class="card-title float-right">
                                                <a data-toggle="collapse" data-parent="#accordion" href="#search">
                                                    <i class="fas fa-filter"></i>Filter
                                                </a>
                                            </h4>
                                        </div>
                                        <div id="search"
                                             class="panel-collapse collapse <?php if($request->city_id != null ||  $request->from_date != null ||  $request->to_date != null): ?>show <?php endif; ?>">
                                            <table class="table table-responsive p-0" width="100%">
                                                <form
                                                        action="<?php echo e(url($page_url)); ?>" autocomplete="off">
                                                    <tr>
                                                        <td style="width: 25%">
                                                            <?php echo e(Form::select('city_id',$cityList->pluck('city_name','id'),Request::get('city_id'),['class'=>'form-control select2','style'=>'width: 100%;','placeholder'=>
                                                     'Select City'])); ?>


                                                        </td>

                                                        <td>
                                                            <?php echo Form::text('from_date',Request::get('from_date'),['class'=>'form-control','id'=>'from_date','autocomplete'=>'off','width'=>'100%','placeholder'=>
                                                                               trans('app.start_date'),'readonly']); ?>

                                                        </td>

                                                        <td>
                                                            <?php echo Form::text('to_date',Request::get('to_date'),['class'=>'form-control','id'=>'to_date','autocomplete'=>'off','width'=>'100%','placeholder'
                                                                                =>
                                                                               trans('app.start_date'),'readonly']); ?>

                                                        </td>


                                                        <td colspan="5"
                                                            class="text-center">
                                                            <button type="submit" class="btn btn-primary"><i
                                                                        class="fa fa-search"></i> <?php echo e(trans('app.filter')); ?>

                                                            </button> &nbsp; &nbsp;
                                                            <a href="<?php echo e(url($page_url)); ?>"
                                                               class="btn btn-default"> <i
                                                                        class="fas  fa-sync-alt"></i> <?php echo e(trans('app.refresh')); ?>

                                                            </a>
                                                            &nbsp; &nbsp;
                                                            <a class="btn btn-danger" data-toggle="collapse"
                                                               data-parent="#accordion" href="#search">
                                                                <span aria-hidden="true">&times;</span> Close
                                                            </a>
                                                        </td>

                                                    </tr>

                                                </form>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.col -->
                            </div>
                        <!-- /.card-header -->
                        <?php if(sizeof($results) > 0): ?>
                            <div class="card-body">
                                <table id="example2" class="table table-striped table-bordered table-hover">
                                    <thead>
                                    <tr>
                                        <th width="10px"><?php echo e(trans('app.sn')); ?></th>
                                        <th><?php echo e(trans('app.name')); ?></th>
                                        <th><?php echo e(trans('City')); ?></th>
                                        <th><?php echo e(trans('app.start_date')); ?></th>
                                        <th><?php echo e(trans('app.end_date')); ?></th>
                                        <th><?php echo e(trans('app.action')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope=row><?php echo e(($results->currentpage()-1) * $results->perpage() + $key+1); ?></th>
                                            <td>
                                                <?php echo e($data->campaign_name); ?>

                                            </td>
                                            <td>
                                                <?php if(isset($data->city->city_name)): ?>
                                                    <?php echo e($data->city->city_name); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php echo e($data->start_date); ?>

                                            </td>
                                            <td>
                                                <?php echo e($data->end_date); ?>

                                            </td>
                                            <td>
                                                <?php if($allowEdit): ?>
                                                    <button type="button" class="btn btn-info btn-xs"
                                                            data-toggle="modal"
                                                            data-target="#editModal<?php echo e($key); ?>"
                                                            data-placement="top" title="Edit">
                                                        <i class="fas fa-pencil-alt"></i>
                                                    </button>
                                                <?php endif; ?>
                                                <?php if($allowDelete): ?>
                                                    <button type="button" class="btn btn-danger btn-xs"
                                                            data-toggle="modal"
                                                            data-target="#deleteModal<?php echo e($key); ?>"
                                                            data-placement="top" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                <?php endif; ?>

                                            </td>
                                        </tr>
                                        <?php echo $__env->make('backend.modal.delete_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                                        <div class="modal fade" id="editModal<?php echo e($key); ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header btn-secondary">
                                                        <h4 class="modal-title"><?php echo e(trans('app.edit')); ?></h4>
                                                        <button type="button" class="close"
                                                                data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true" data-toggle="tooltip"
                                                                      title="Close">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col-md-12">

                                                                <?php echo Form::model($data,['method'=>'PUT','route'=>[$page_route.'.'.'update',$data->id]]); ?>

                                                                <div class="row">
                                                                    <div class="form-group col-md-6 <?php echo e(($errors->has('city_id'))?'has-error':''); ?>">
                                                                        <label><?php echo e(trans('City Name ')); ?></label>
                                                                        <label
                                                                                class="text text-danger"> *</label>
                                                                        <?php echo e(Form::select('city_id',$cityList->pluck('city_name','id'),Request::get('city_id'),['class'=>'form-control select2','style'=>'width: 100%;','placeholder'=>
                                                                    'Select City'])); ?>


                                                                        <?php echo $errors->first('district_id', '<span class="text text-danger">:message</span>'); ?>

                                                                    </div>
                                                                    <div class="form-group col-md-6  <?php echo e(($errors->has('campaign_name'))?'has-error':''); ?>">
                                                                        <label><?php echo e(trans('app.name')); ?></label> <label
                                                                                class="text text-danger"> *</label>

                                                                        <?php echo Form::text('campaign_name',null,['class'=>'form-control','placeholder'=>'Campaign Name']); ?>

                                                                        <?php echo $errors->first('campaign_name', '<span class="text text-danger">:message</span>'); ?>

                                                                    </div>
                                                                    <div class="form-group col-md-6 <?php echo e(($errors->has('start_date'))?'has-error':''); ?>">
                                                                        <label><?php echo e(trans('app.start_date')); ?></label>
                                                                        <label
                                                                                class="text text-danger"> *</label>

                                                                        <?php echo Form::text('start_date',null,['class'=>'form-control startDate','placeholder'=>'Campaign Start Date']); ?>

                                                                        <?php echo $errors->first('start_date', '<span class="text text-danger">:message</span>'); ?>

                                                                    </div>
                                                                    <div class="form-group col-md-6 <?php echo e(($errors->has('end_date'))?'has-error':''); ?>">
                                                                        <label><?php echo e(trans('app.end_date')); ?></label>
                                                                        <label
                                                                                class="text text-danger"> *</label>

                                                                        <?php echo Form::text('end_date',null,['class'=>'form-control endDate','placeholder'=>'Campaign End Date']); ?>

                                                                        <?php echo $errors->first('end_date', '<span class="text text-danger">:message</span>'); ?>

                                                                    </div>
                                                                    <div class="form-group col-md-12 <?php echo e(($errors->has('details'))?'has-error':''); ?>">
                                                                        <label for="inputDescription"><?php echo e(trans('app.details')); ?></label>
                                                                        <?php echo Form::textarea('description',null,['class'=>'form-control','placeholder'=>'Enter Campaign Details','rows'=>'4','autocomplete'=>'off']); ?>

                                                                        <?php echo $errors->first('description', '<span class="label label-danger">:message</span>'); ?>

                                                                    </div>

                                                                </div>
                                                                <div class="modal-footer justify-content-center">

                                                                    <button type="submit"
                                                                            class="btn btn-success"><?php echo e(trans('app.update')); ?></button>
                                                                    &nbsp; &nbsp; &nbsp; &nbsp;
                                                                    <button type="button"
                                                                            class="btn btn-danger"
                                                                            data-dismiss="modal">
                                                                        <?php echo e(trans('app.cancel')); ?>

                                                                    </button>
                                                                </div>
                                                                <?php echo Form::close(); ?>


                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <span class="float-right"><?php echo e($results->appends(request()->except('page'))->links()); ?>

                                </span>
                            </div>
                            <!-- /.card-body -->
                        <?php else: ?>
                            <div class="col-md-12" style="padding-top: 10px">
                                <label class="form-control badge badge-info"
                                       style="text-align:  center; font-size: 18px;">
                                    <i class="fas fa-ban"></i> No record found yet !.
                                </label>
                            </div>
                    </div>
                <?php endif; ?>
                <!-- /.card -->


                    <div class="modal fade" id="addModal">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header" style="background: #6c757d">
                                    <h4 class="modal-title"><?php echo e(trans('app.add')); ?></h4>
                                    <button type="button" class="close" data-dismiss="modal"
                                            aria-label="Close">
                                        <span aria-hidden="true" data-toggle="tooltip" title="Close">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="col-md-12">

                                            <?php echo Form::open(['method'=>'post','url'=>$page_url]); ?>

                                            <div class="row">
                                                <div class="form-group col-md-6 <?php echo e(($errors->has('city_id'))?'has-error':''); ?>">
                                                    <label><?php echo e(trans('City Name ')); ?></label> <label
                                                            class="text text-danger"> *</label>
                                                    <?php echo e(Form::select('city_id',$cityList->pluck('city_name','id'),Request::get('city_id'),['class'=>'form-control select2','style'=>'width: 100%;','placeholder'=>
                                                'Select City'])); ?>


                                                    <?php echo $errors->first('city_id', '<span class="text text-danger">:message</span>'); ?>

                                                </div>
                                                <div class="form-group col-md-6  <?php echo e(($errors->has('campaign_name'))?'has-error':''); ?>">
                                                    <label><?php echo e(trans('app.name')); ?></label> <label
                                                            class="text text-danger"> *</label>

                                                    <?php echo Form::text('campaign_name',null,['class'=>'form-control','placeholder'=>'Campaign Name']); ?>

                                                    <?php echo $errors->first('campaign_name', '<span class="text text-danger">:message</span>'); ?>

                                                </div>

                                                <div class="form-group col-md-6 <?php echo e(($errors->has('start_date'))?'has-error':''); ?>">
                                                    <label><?php echo e(trans('app.start_date')); ?></label> <label
                                                            class="text text-danger"> *</label>

                                                    <?php echo Form::text('start_date',null,['class'=>'form-control startDate','placeholder'=>'Campaign Start Date','autocomplete'=>'off']); ?>

                                                    <?php echo $errors->first('start_date', '<span class="text text-danger">:message</span>'); ?>

                                                </div>
                                                <div class="form-group col-md-6 <?php echo e(($errors->has('end_date'))?'has-error':''); ?>">
                                                    <label><?php echo e(trans('app.end_date')); ?></label> <label
                                                            class="text text-danger"> *</label>

                                                    <?php echo Form::text('end_date',null,['class'=>'form-control endDate','placeholder'=>'Campaign End Date','autocomplete'=>'off']); ?>

                                                    <?php echo $errors->first('end_date', '<span class="text text-danger">:message</span>'); ?>

                                                </div>
                                                <div class="form-group col-md-12 <?php echo e(($errors->has('details'))?'has-error':''); ?>">
                                                    <label for="inputDescription"><?php echo e(trans('app.details')); ?></label>
                                                    <?php echo Form::textarea('description',null,['class'=>'form-control','placeholder'=>'Enter Campaign Details','rows'=>'4','autocomplete'=>'off']); ?>

                                                    <?php echo $errors->first('description', '<span class="label label-danger">:message</span>'); ?>

                                                </div>

                                            </div>


                                            <div class="modal-footer justify-content-center">

                                                <button type="submit"
                                                        class="btn btn-primary"><?php echo e(trans('app.save')); ?></button>
                                                &nbsp; &nbsp;
                                                <button type="button" class="btn btn-danger"
                                                        data-dismiss="modal">
                                                    <?php echo e(trans('app.cancel')); ?>

                                                </button>
                                            </div>
                                            <?php echo Form::close(); ?>


                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                    </div>

                    <!-- /.col -->
                </div>
            </div>
            <!-- /.row -->
    </div>
    </section>
    <!-- /.container-fluid -->
    <!-- /.content -->

    </div>

    <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/crm_setup/resources/views/backend/campaign.blade.php ENDPATH**/ ?>