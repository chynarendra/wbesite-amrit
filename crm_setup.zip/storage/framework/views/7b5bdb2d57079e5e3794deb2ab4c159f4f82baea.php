<title><?php echo $__env->yieldContent('page_title',$page_title); ?></title>
<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">

            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo e(trans('Customer Query')); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>"><?php echo e(trans('app.dashboard')); ?></a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(url($page_url)); ?>"><?php echo e(trans('Customer Query')); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo e(trans('app.edit')); ?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <?php echo $__env->make('backend.message.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
                <div class="col-md-12" id="listing">
                    <div class="card card-default">
                        <div class="card-header with-border">
                            <h3 class="card-title"> <?php echo e(trans('app.edit')); ?></h3>
                            <?php

                            $permission = helperPermissionLink(url($page_url.'/'.'create'), url($page_url));

                            $allowEdit = $permission['isEdit'];

                            $allowDelete = $permission['isDelete'];

                            $allowAdd = $permission['isAdd'];
                            ?>

                        </div>
                        <div class="card-body">
                            <?php echo Form::model($edits, ['method'=>'put','route'=>[$page_route.'.'.'update',$edits->id],'enctype'=>'multipart/form-data','file'=>true]); ?>


                            <div class="row">
                                <div class="form-group col-md-4 <?php echo e(($errors->has('source_of_query_id'))?'has-error':''); ?>">
                                    <label>Query Source</label><label class="text-danger">*</label>
                                    <?php echo Form::select('source_of_query_id',$sourceList->pluck('name','id'),null,['style' => 'width:100%','class'=>'form-control select2','placeholder'=>'Please Select Source
                                    ']); ?>

                                    <?php echo $errors->first('source_of_query_id', '<span class="text-danger">:message</span>'); ?>

                                </div>

                                <div class="form-group col-md-4 <?php echo e(($errors->has('name'))?'has-error':''); ?>">
                                    <label for="feature">Name</label><label class="text-danger">*</label>
                                    <?php echo e(Form::text('name',null,['placeholder'=>'Customer Name','class' => 'form-control'])); ?>

                                    <?php echo $errors->first('name', '<span class="text-danger">:message</span>'); ?>

                                </div>

                                <div class="form-group col-md-4 <?php echo e(($errors->has('address'))?'has-error':''); ?>">
                                    <label for="feature">Address</label><label class="text-danger">*</label>
                                    <?php echo e(Form::text('address',null,['placeholder'=>'Customer Address','class' => 'form-control'])); ?>

                                    <?php echo $errors->first('address', '<span class="text-danger">:message</span>'); ?>

                                </div>

                                <div class="form-group col-md-4 <?php echo e(($errors->has('email'))?'has-error':''); ?>">
                                    <label for="feature">Email</label>
                                    <?php echo e(Form::email('email',null,['placeholder'=>'Customer Email Address','class' => 'form-control'])); ?>

                                    <?php echo $errors->first('email', '<span class="text-danger">:message</span>'); ?>

                                </div>

                                <div class="form-group col-md-4 <?php echo e(($errors->has('ph_no'))?'has-error':''); ?>">
                                    <label for="feature">Phone No.</label><label class="text-danger">*</label>
                                    <?php echo e(Form::number('ph_no',null,['placeholder'=>'Customer Contact Number','class' => 'form-control'])); ?>

                                    <?php echo $errors->first('ph_no', '<span class="text-danger">:message</span>'); ?>

                                </div>

                                <div class="form-group col-md-12 <?php echo e(($errors->has('question'))?'has-error':''); ?>">
                                    <label for="feature">Question ?</label>
                                    <?php echo e(Form::textarea('question',null,['placeholder'=>'','class' => 'textarea', 'style' => 'width: 100%; height: 34opx; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px; cols: 200;'])); ?>

                                    <?php echo $errors->first('question', '<span class="text-danger">:message</span>'); ?>

                                </div>

                            </div>

                            <div class="form-group col-md-12 text-center">
                                <button type="submit" class="btn btn-success">
                                    <?php echo e(trans('app.update')); ?>

                                </button>
                                &nbsp;
                                <a  class="btn btn-danger" href="<?php echo e(url($page_url)); ?>"><?php echo e(trans('app.cancel')); ?></a>
                            </div>

                            <?php echo e(Form::close()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/crm_setup/resources/views/backend/customer/customer_query/edit.blade.php ENDPATH**/ ?>