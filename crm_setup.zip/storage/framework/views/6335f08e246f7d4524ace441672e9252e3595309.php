<?php $__env->startSection('js'); ?>
    <script>
        <?php if(Session::has('success')): ?>
        toastr.success("<?php echo e(Session::get('success')); ?>");
        <?php endif; ?>


        <?php if(Session::has('info')): ?>
        toastr.info("<?php echo e(Session::get('info')); ?>");
        <?php endif; ?>


        <?php if(Session::has('warning')): ?>
        toastr.warning("<?php echo e(Session::get('warning')); ?>");
        <?php endif; ?>


        <?php if(Session::has('error')): ?>
        toastr.error("<?php echo e(Session::get('error')); ?>");
        <?php endif; ?>
        <?php if(count($errors) > 0): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        toastr.error("<?php echo e($error); ?>");
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>


    </script>
<?php $__env->stopSection(); ?><?php /**PATH /var/www/html/new_success/resources/views/backend/message/flash.blade.php ENDPATH**/ ?>