<div class="card card-default">
    <div class="card-header with-border">
        <h3 class="card-title"><?php echo e(trans('app.add')); ?>&nbsp;</h3>

    </div>
    <div class="card-body">
    <?php echo Form::open(['method'=>'post','url'=>'/customer/purchaseproduct/store/'.$customerId]); ?>



        <div class="row">

            <div class="form-group <?php echo e(($errors->has('product_id'))?'has-error':''); ?>">
                <label> Product</label><label class="text-danger">*</label>
                <?php echo Form::select('product_id',$productList->pluck('product_name','id'),null,['style' => 'width:100%','class'=>'form-control select2','placeholder'=>'Please Select Product
                ']); ?>

                <?php echo $errors->first('product_id', '<span class="text-danger">:message</span>'); ?>

            </div>
            <div class="form-group <?php echo e(($errors->has('office_id'))?'has-error':''); ?>">
                <label> Purchase Office</label><label class="text-danger">*</label>
                <?php echo Form::select('office_id',$officeList->pluck('office_name','id'),null,['style' => 'width:100%','class'=>'form-control select2','placeholder'=>'Please Select Office
                ']); ?>

                <?php echo $errors->first('office_id', '<span class="text-danger">:message</span>'); ?>

            </div>

            <div class="form-group <?php echo e(($errors->has('purchase_date'))?'has-error':''); ?>">
                <label for="feature">Purchase Date</label><label class="text-danger">*</label>
                <?php echo e(Form::text('purchase_date',null,['placeholder'=>'Purchase date','class' => 'form-control purchaseDate','id'=>'purchaseDate','autocomplete'=>'off','readonly'])); ?>

                <?php echo $errors->first('purchase_date', '<span class="text-danger">:message</span>'); ?>

            </div>

            <div class="form-group <?php echo e(($errors->has('remarks'))?'has-error':''); ?>">
                <label for="feature">Remarks</label>
                <?php echo e(Form::textarea('remarks',null,['placeholder'=>'Write Down','class' => 'form-control'])); ?>

                <?php echo $errors->first('remarks', '<span class="text-danger">:message</span>'); ?>

            </div>

            <div class="form-group col-md-12">
                <button type="submit" class="btn btn-primary">
                    <?php echo e(trans('app.save')); ?>

                </button>
            </div>

        </div>

        <?php echo Form::close(); ?>


    </div>
    <!-- /.card-body -->
</div>
<!-- /.card -->
<?php /**PATH /var/www/html/crm_setup/resources/views/backend/customer/purchaseProduct/add.blade.php ENDPATH**/ ?>