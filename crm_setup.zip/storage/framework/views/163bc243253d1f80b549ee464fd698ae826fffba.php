<title><?php echo $__env->yieldContent('page_title',$page_title); ?></title>
<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e(trans('Setting')); ?></h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>"> <?php echo e(trans('app.dashboard')); ?></a>
                            </li>
                            <li class="breadcrumb-item"><a href="#"><?php echo e(trans('Setting')); ?></a></li>
                            <li class="breadcrumb-item"><?php echo e($page_title); ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <?php echo $__env->make('backend.message.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header" style="text-align:right">
                                <h3 class="card-title"><?php echo e($page_title); ?></h3>


                                <?php

                                $permission = helperPermission();

                                $allowEdit = $permission['isEdit'];

                                $allowDelete = $permission['isDelete'];

                                $allowAdd = $permission['isAdd'];

                                ?>
                                <a href="<?php echo e(URL::previous()); ?>" class="pull-right" data-toggle="tooltip"
                                   title="Add New">
                                    <i class="fa fa-arrow-circle-left fa-2x"></i></a>
                                <a href="<?php echo e(url($page_url)); ?>" class="pull-right" data-toggle="tooltip"
                                   title="View List">
                                    <i class="fa fa-list fa-2x"></i></a>
                                <?php if($allowAdd): ?>
                                    <a href="" class="pull-right" data-toggle="modal"
                                       data-target="#addModal"
                                       title="Add New">
                                        <i class="fa fa-plus-circle fa-2x"></i></a>
                                <?php endif; ?>

                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example2" class="table table-bordered">
                                    <thead>
                                    <tr>
                                        <th width="10px"><?php echo e(trans('app.sn')); ?></th>
                                        <th><?php echo e(trans('app.name')); ?></th>
                                        <th><?php echo e(trans('app.short_name')); ?></th>
                                        <th><?php echo e(trans('app.status')); ?></th>
                                        <th><?php echo e(trans('app.action')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope=row><?php echo e(($results->currentpage()-1) * $results->perpage() + $key+1); ?></th>
                                            <td>
                                                <?php echo e($data->name); ?>

                                            </td>
                                            <td>
                                                <?php echo e($data->short_name); ?>

                                            </td>
                                            <td>
                                                <?php if($data->status == '1'): ?>
                                                    <button type="button" class="btn btn-success btn-xs"
                                                            data-toggle="modal"
                                                            data-target="#statusModal<?php echo e($key); ?>"
                                                            title="Click here update  status">
                                                        <?php echo e(trans('app.active')); ?>

                                                    </button>
                                                <?php elseif($data->status== '0'): ?>
                                                    <button type="button" class="btn btn-danger btn-xs"
                                                            data-toggle="modal"
                                                            data-target="#statusModal<?php echo e($key); ?>"
                                                            title="Click here update  status">
                                                        <?php echo e(trans('app.inactive')); ?>

                                                    </button>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($allowEdit): ?>
                                                    <button type="button" class="btn btn-info btn-xs"
                                                            data-toggle="modal"
                                                            data-target="#editModal<?php echo e($key); ?>"
                                                            data-placement="top" title="Edit">
                                                        <i class="fas fa-pencil-alt"></i>
                                                    </button>
                                                <?php endif; ?>
                                                <?php if($allowDelete): ?>
                                                    <button type="button" class="btn btn-danger btn-xs"
                                                            data-toggle="modal"
                                                            data-target="#deleteModal<?php echo e($key); ?>"
                                                            data-placement="top" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                <?php endif; ?>

                                            </td>
                                        </tr>
                                        <?php echo $__env->make('backend.modal.status_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php echo $__env->make('backend.modal.delete_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                                        <div class="modal fade" id="editModal<?php echo e($key); ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header btn-secondary">
                                                        <h4 class="modal-title"><?php echo e(trans('app.edit')); ?></h4>
                                                        <button type="button" class="close"
                                                                data-dismiss="modal"
                                                                aria-label="Close">
                                                            <span aria-hidden="true" data-toggle="tooltip" title="Close">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col-md-12">

                                                                <?php echo Form::model($data,['method'=>'PUT','route'=>[$page_route.'.'.'update',$data->id]]); ?>

                                                                <div class="form-group">
                                                                    <label for="inputName"><?php echo e(trans('app.name')); ?></label> <label class="text text-danger">*</label>
                                                                    <?php echo Form::text('name',null,['class'=>'form-control','placeholder'=>'Product Category  Name','autocomplete'=>'off']); ?>

                                                                    <?php echo $errors->first('name', '<small class="text text-danger">:message</small>'); ?>

                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="inputName"><?php echo e(trans('app.short_name')); ?></label>
                                                                    <?php echo Form::text('short_name',null,['class'=>'form-control','placeholder'=>'Product Category Short  Name','autocomplete'=>'off']); ?>

                                                                    <?php echo $errors->first('short_name', '<small class="text text-danger">:message</small>'); ?>

                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="status"><?php echo e(trans('app.status')); ?> </label><br>
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="radio" id="readio1"
                                                                               name="status" value="1"
                                                                               <?php if($data->status=='1'): ?> checked <?php endif; ?>>
                                                                        <label for="readio1">
                                                                            <?php echo e(trans('app.active')); ?>

                                                                        </label>
                                                                    </div>
                                                                    &nbsp; &nbsp;
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="radio" id="readio2"
                                                                               name="status"
                                                                               value="0"   <?php if($data->status=='0'): ?> checked <?php endif; ?>>
                                                                        <label for="readio2">
                                                                            <?php echo e(trans('app.inactive')); ?>

                                                                        </label>
                                                                    </div>

                                                                </div>
                                                                <div class="modal-footer justify-content-center">

                                                                    <button type="submit"
                                                                            class="btn btn-success"><?php echo e(trans('app.update')); ?></button>
                                                                    &nbsp; &nbsp; &nbsp; &nbsp;
                                                                    <button type="button"
                                                                            class="btn btn-danger"
                                                                            data-dismiss="modal">
                                                                        <?php echo e(trans('app.cancel')); ?>

                                                                    </button>
                                                                </div>
                                                                <?php echo Form::close(); ?>


                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <span class="float-right"><?php echo e($results->appends(request()->except('page'))->links()); ?>

                                </span>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->


                        <div class="modal fade" id="addModal">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header" style="background: #6c757d">
                                        <h4 class="modal-title"><?php echo e(trans('app.add')); ?></h4>
                                        <button type="button" class="close" data-dismiss="modal"
                                                aria-label="Close">
                                            <span aria-hidden="true" data-toggle="tooltip" title="Close">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-md-12">

                                                <?php echo Form::open(['method'=>'post','url'=>$page_url]); ?>

                                                <div class="form-group">
                                                    <label for="inputName"><?php echo e(trans('app.name')); ?></label> <label class="text text-danger">*</label>
                                                    <?php echo Form::text('name',null,['class'=>'form-control','placeholder'=>'Product Category  Name','autocomplete'=>'off']); ?>

                                                    <?php echo $errors->first('name', '<small class="text text-danger">:message</small>'); ?>

                                                </div>
                                                <div class="form-group">
                                                    <label for="inputName"><?php echo e(trans('app.short_name')); ?></label>
                                                    <?php echo Form::text('short_name',null,['class'=>'form-control','placeholder'=>'Product Category Short  Name','autocomplete'=>'off']); ?>

                                                    <?php echo $errors->first('short_name', '<small class="text text-danger">:message</small>'); ?>

                                                </div>
                                                <div class="form-group">
                                                    <label for="status"><?php echo e(trans('app.status')); ?> </label><br>
                                                    <div class="icheck-success d-inline">
                                                        <input type="radio" id="readio3"
                                                               name="status" value="1"
                                                               checked>
                                                        <label for="readio3">
                                                            <?php echo e(trans('app.active')); ?>

                                                        </label>
                                                    </div>
                                                    &nbsp; &nbsp;
                                                    <div class="icheck-success d-inline">
                                                        <input type="radio" id="readio4"
                                                               name="status"
                                                               value="0">
                                                        <label for="readio4">
                                                            <?php echo e(trans('app.inactive')); ?>

                                                        </label>
                                                    </div>

                                                </div>


                                                <div class="modal-footer justify-content-center">

                                                    <button type="submit"
                                                            class="btn btn-primary"><?php echo e(trans('app.save')); ?></button>
                                                    &nbsp; &nbsp;
                                                    <button type="button" class="btn btn-danger"
                                                            data-dismiss="modal">
                                                        <?php echo e(trans('app.cancel')); ?>

                                                    </button>
                                                </div>
                                                <?php echo Form::close(); ?>


                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.modal-content -->
                            </div>
                            <!-- /.modal-dialog -->
                        </div>

                        <!-- /.col -->
                    </div>
                </div>
                <!-- /.row -->
            </div>
        </section>
        <!-- /.container-fluid -->
        <!-- /.content -->

    </div>

    <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/crm_setup/resources/views/backend/configurations/productCategory.blade.php ENDPATH**/ ?>