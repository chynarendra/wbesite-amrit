<title><?php echo $__env->yieldContent('page_title',$page_title); ?></title>
<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">

            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo e(trans('Customer')); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>"><?php echo e(trans('app.dashboard')); ?></a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(url($page_url)); ?>"><?php echo e(trans('Customer')); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo e(trans('app.edit')); ?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <?php echo $__env->make('backend.message.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
                <div class="col-md-12" id="listing">
                    <div class="card card-default">
                        <div class="card-header with-border">
                            <h3 class="card-title"> <?php echo e(trans('app.edit')); ?></h3>
                            <?php

                            $permission = helperPermissionLink(url($page_url.'/'.'create'), url($page_url));

                            $allowEdit = $permission['isEdit'];

                            $allowDelete = $permission['isDelete'];

                            $allowAdd = $permission['isAdd'];
                            ?>

                        </div>
                        <div class="card-body">
                            <?php echo Form::model($edits, ['method'=>'put','route'=>[$page_route.'.'.'update',$edits->id],'enctype'=>'multipart/form-data','file'=>true]); ?>


                            <div class="row">
                                <div class="form-group col-md-4 <?php echo e(($errors->has('source_id'))?'has-error':''); ?>">
                                    <label>Source</label> <label class="text text-danger">*</label>
                                    <?php echo Form::select('customer_source_id',$sourceList->pluck('name','id'),null,['id' => 'source_id','style' => 'width:100%','class'=>'form-control select2','placeholder'=>'Please Select Source
                                    ']); ?>

                                    <?php echo $errors->first('customer_source_id', '<span class="text-danger">:message</span>'); ?>

                                </div>
                                <div class="form-group col-md-4 <?php echo e(($errors->has('campaign_id'))?'has-error':''); ?>" id="champaign_list" style="display: none">
                                    <label>Campaign</label><label class="text-danger">*</label>
                                    <?php echo Form::select('campaign_id',$campaignList->pluck('campaign_name','id'),null,['id' => 'campaignId','style' => 'width:100%','class'=>'form-control select2','placeholder'=>'Please Select Campaign
                                    ','required']); ?>

                                    <?php echo $errors->first('campaign_id', '<span class="text-danger">:message</span>'); ?>

                                </div>

                                <div class="form-group col-md-4 <?php echo e(($errors->has('customer_name'))?'has-error':''); ?>">
                                    <label for="feature">Name</label><label class="text-danger">*</label>
                                    <?php echo e(Form::text('customer_name',null,['placeholder'=>'Customer Name','class' => 'form-control'])); ?>

                                    <?php echo $errors->first('customer_name', '<span class="text-danger">:message</span>'); ?>

                                </div>


                                <div class="form-group col-md-4 <?php echo e(($errors->has('address'))?'has-error':''); ?>">
                                    <label for="feature"> Address</label><label class="text-danger">*</label>
                                    <?php echo e(Form::text('address',null,['placeholder'=>'Customer  Address','class' => 'form-control'])); ?>

                                    <?php echo $errors->first('address', '<span class="text-danger">:message</span>'); ?>

                                </div>

                                <div class="form-group col-md-4 <?php echo e(($errors->has('contact'))?'has-error':''); ?>">
                                    <label for="feature"> Contact</label><label class="text-danger">*</label>
                                    <?php echo e(Form::number('contact',null,['placeholder'=>'Customer  Contact Number','class' => 'form-control'])); ?>

                                    <?php echo $errors->first('contact', '<span class="text-danger">:message</span>'); ?>

                                </div>

                                <div class="form-group col-md-4 <?php echo e(($errors->has('email'))?'has-error':''); ?>">
                                    <label for="feature"> Email</label>
                                    <?php echo e(Form::text('email',null,['placeholder'=>'Customer  Email Address','class' => 'form-control'])); ?>

                                    <?php echo $errors->first('email', '<span class="text-danger">:message</span>'); ?>

                                </div>

                                <div class="form-group col-md-4 <?php echo e(($errors->has('followup_date'))?'has-error':''); ?>">
                                    <label for="feature"> Status</label><label class="text-danger">*</label>
                                    <?php echo e(Form::select('status',customerStatus(),Request::get('status'),['class'=>'form-control select2','placeholder'=>
                                                            'Select Customer Status'])); ?>

                                    <?php echo $errors->first('status', '<span class="text-danger">:message</span>'); ?>

                                </div>

                            </div>
                            <hr/>

                            <div class="row">

                                <div class="form-group col-md-4 <?php echo e(($errors->has('followup_date'))?'has-error':''); ?>">
                                    <label for="feature"> Followup Date</label>
                                    <?php echo e(Form::text('followup_date',null,['placeholder'=>' Followup Date','id'=>'follow_date','autocomplete'=>'off','class' => 'form-control','readonly'])); ?>

                                    <?php echo $errors->first('followup_date', '<span class="text-danger">:message</span>'); ?>

                                </div>

                                <div class="form-group col-md-12 <?php echo e(($errors->has('about_product'))?'has-error':''); ?>">
                                    <label for="feature">Customer View</label>
                                    <?php echo e(Form::textarea('note',null,['placeholder'=>'','class' => 'textarea', 'style' => 'width: 100%; height: 34opx; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px; cols: 200;'])); ?>

                                </div>

                            </div>

                            <div class="form-group col-md-12 text-center">
                                <button type="submit" class="btn btn-success">
                                    <?php echo e(trans('app.update')); ?>

                                </button>
                                &nbsp;
                                <a  class="btn btn-danger" href="<?php echo e(url($page_url)); ?>"><?php echo e(trans('app.cancel')); ?></a>
                            </div>

                            <?php echo e(Form::close()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/crm_setup/resources/views/backend/customer/edit.blade.php ENDPATH**/ ?>