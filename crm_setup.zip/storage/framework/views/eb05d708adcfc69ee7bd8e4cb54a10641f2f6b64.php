<title><?php echo $__env->yieldContent('page_title',$page_title); ?></title>
<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">

            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo e(trans('Customer')); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>"><?php echo e(trans('app.dashboard')); ?></a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(url($page_url)); ?>"><?php echo e(trans('Customer')); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo e(trans('app.edit')); ?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <?php echo $__env->make('backend.message.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
                <div class="col-md-12" id="listing">
                    <div class="card card-default">
                        <div class="card-header with-border">
                            <h3 class="card-title"> <?php echo e(trans('app.edit')); ?></h3>
                            <?php

                            $permission = helperPermissionLink(url($page_url.'/'.'create'), url($page_url));

                            $allowEdit = $permission['isEdit'];

                            $allowDelete = $permission['isDelete'];

                            $allowAdd = $permission['isAdd'];
                            ?>

                        </div>
                        <div class="card-body">
                            <?php echo Form::model($edits, ['method'=>'put','route'=>[$page_route.'.'.'update',$edits->id]]); ?>


                            <div class="row">
                                <div class="form-group col-md-4 <?php echo e(($errors->has('customer_id'))?'has-error':''); ?>">
                                    <label> Customer</label><label class="text-danger">*</label>
                                    <?php echo Form::select('customer_id',$customerList->pluck('customer_name','id'),null,['id' => 'cityId','style' => 'width:100%','class'=>'form-control select2','placeholder'=>'Please Select Customer
                                    ']); ?>

                                    <?php echo $errors->first('customer_id', '<span class="text-danger">:message</span>'); ?>

                                </div>

                                <div class="form-group col-md-4 <?php echo e(($errors->has('product_id'))?'has-error':''); ?>">
                                    <label> Product</label><label class="text-danger">*</label>
                                    <?php echo Form::select('product_id',$productList->pluck('product_name','id'),null,['id' => 'cityId','style' => 'width:100%','class'=>'form-control select2','placeholder'=>'Please Select Product
                                    ']); ?>

                                    <?php echo $errors->first('product_id', '<span class="text-danger">:message</span>'); ?>

                                </div>

                                <div class="form-group col-md-4 <?php echo e(($errors->has('payment_method_id'))?'has-error':''); ?>">
                                    <label> Payment Method</label><label class="text-danger">*</label>
                                    <?php echo Form::select('payment_method_id',$paymentMethodList->pluck('method_name','id'),null,['id' => 'cityId','style' => 'width:100%','class'=>'form-control select2','placeholder'=>'Select payment method
                                    ']); ?>

                                    <?php echo $errors->first('payment_method_id', '<span class="text-danger">:message</span>'); ?>

                                </div>

                                <div class="form-group col-md-4 <?php echo e(($errors->has('paid_amount'))?'has-error':''); ?>">
                                    <label for="feature">Paid Amount</label><label class="text-danger">*</label>
                                    <?php echo e(Form::text('paid_amount',null,['placeholder'=>'Amount ( in Rs.)','class' => 'form-control'])); ?>

                                    <?php echo $errors->first('paid_amount', '<span class="text-danger">:message</span>'); ?>

                                </div>

                                <div class="form-group col-md-4 <?php echo e(($errors->has('paid_date'))?'has-error':''); ?>">
                                    <label for="feature">Paid Date</label><label class="text-danger">*</label>
                                    <?php echo e(Form::text('paid_date',null,['placeholder'=>'Paid date','class' => 'form-control','id'=>'eng_date','autocomplete'=>'off'])); ?>

                                    <?php echo $errors->first('paid_date', '<span class="text-danger">:message</span>'); ?>

                                </div>

                                <div class="form-group col-md-12 <?php echo e(($errors->has('remarks'))?'has-error':''); ?>">
                                    <label for="feature">Remarks</label>
                                    <?php echo e(Form::textarea('remarks',null,['placeholder'=>'','class' => 'textarea', 'style' => 'width: 100%; height: 34opx; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px; cols: 300;'])); ?>


                                    <?php echo $errors->first('remarks', '<span class="text-danger">:message</span>'); ?>

                                </div>

                            </div>

                            <div class="form-group col-md-12 text-center">
                                <button type="submit" class="btn btn-success" name="submit" value="1">
                                    <?php echo e(trans('app.update')); ?>

                                </button>
                                &nbsp;
                                <a  class="btn btn-danger" href="<?php echo e(url($page_url)); ?>"><?php echo e(trans('app.cancel')); ?></a>
                            </div>

                            <?php echo e(Form::close()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/crm_setup/resources/views/backend/payment/edit.blade.php ENDPATH**/ ?>