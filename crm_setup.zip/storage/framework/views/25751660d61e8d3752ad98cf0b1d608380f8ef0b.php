<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php if(isset(systemSetting()->app_name)): ?><?php echo e(systemSetting()->app_name); ?> <?php else: ?> <?php echo e(env('APP_NAME')); ?>  <?php endif; ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('images/logo.jpg')); ?>">

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- iCheck for checkboxes and radio inputs -->
    <link rel="stylesheet" href="<?php echo e(url('plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(url('theme-design/css/adminlte.min.css')); ?>">
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(url('plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
    <!-- Bootstrap Toggle -->
    <link rel="stylesheet" href="<?php echo e(url('plugins/bootstrap-toggle/css/bootstrap-toggle.min.css')); ?>">
    <!-- Toastr -->
    <link rel="stylesheet" href="<?php echo e(url('plugins/toastr/toastr.min.css')); ?>">
    <!-- English Datepicker -->
    <link rel="stylesheet" type="text/css"
          href="<?php echo e(url('plugins/english-datepicker/english-datepicker.css')); ?>"/>
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(url('plugins/select2/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/style.css')); ?>">

</head><?php /**PATH /var/www/html/api_setup/resources/views/backend/layouts/head.blade.php ENDPATH**/ ?>