<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->

        <section class="content-header">

            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-9">
                        <h1><span class="text text-info"><?php echo e($details->customer_name); ?></span> <?php echo e(trans('Details')); ?>

                            <a href="<?php echo e(route('customer'.'.'.'edit',[$details->id])); ?>"
                               class="btn btn-secondary btn-xs" data-toggle="tooltip" data-placement="top" title="Edit">
                                <i class="fas fa-pencil-alt"></i>
                            </a>
                        </h1>

                    </div>
                    <div class="col-sm-3">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>"><?php echo e(trans('app.dashboard')); ?></a>
                            </li>
                            <li class="breadcrumb-item"><a href="<?php echo e(url($page_url)); ?>"><?php echo e(trans('Customer')); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo e(trans('app.details')); ?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-3">

                        <!-- Profile Image -->
                        <div class="card card-primary card-outline">
                            <div class="card-body box-profile">
                                <div class="text-center">
                                    <img class="profile-user-img img-fluid img-circle img-responsive"
                                         src="<?php echo e(asset('/images/dummyUser.gif')); ?>" alt="Profile picture">
                                </div>

                                <h3 class="profile-username text-center"><?php echo e($details->customer_name); ?></h3>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->

                        <!-- About Me Box -->
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">About</h3>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <strong><i class="fas fa-location-arrow mr-1"></i> Address</strong>

                                <p class="text-muted">
                                    <?php echo e($details->address); ?>

                                </p>

                                <hr>

                                <strong><i class="fas fa-phone mr-1"></i> Contact Number</strong>

                                <p class="text-muted"><?php echo e($details->contact); ?></p>

                                <hr>

                                <strong><i class="fas fa-envelope mr-1"></i> Email Address</strong>

                                <p class="text-muted">
                                    <?php if($details->email !=null): ?>
                                        <?php echo e($details->email); ?>

                                    <?php else: ?>
                                        Not Available
                                    <?php endif; ?>
                                </p>

                                <hr>

                                <strong><i class="fas fa-cube mr-1"></i> Status</strong>

                                <!-- Trigger the modal with a button -->
                                <?php
                                $key = $details->id;
                                ?>
                                <?php if($details->status == '1'): ?>
                                    <button class="btn btn-danger btn-xs" data-toggle="modal"
                                            data-target="#updateStatusModal"
                                            data-placement="top" title="Update Status"
                                    ><?php echo e(customerStatus($details->status)); ?></button>
                                <?php elseif($details->status == '2'): ?>
                                    <button class="btn btn-secondary btn-xs" data-toggle="modal"
                                            data-target="#updateStatusModal"
                                            data-placement="top"
                                            title="Update Status"><?php echo e(customerStatus($details->status)); ?></button>

                                <?php elseif($details->status == '3'): ?>
                                    <button class="btn btn-success btn-xs" data-toggle="modal"
                                            data-target="#updateStatusModal"
                                            data-placement="top"
                                            title="Update Status"><?php echo e(customerStatus($details->status)); ?></button>
                                <?php elseif($details->status == '4'): ?>
                                    <button class="btn btn-warning btn-xs" data-toggle="modal"
                                            data-target="#updateStatusModal"
                                            data-placement="top"
                                            title="Update Status"><?php echo e(customerStatus($details->status)); ?></button>
                                <?php elseif($details->status == '5'): ?>
                                    <button class="btn btn-primary btn-xs"><?php echo e(customerStatus($details->status)); ?></button>
                                <?php endif; ?>

                                
                                <div class="modal fade" id="updateStatusModal">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header btn-info">
                                                <h4 class="modal-title"><?php echo e(trans('Are you sure you want to update status?')); ?></h4>
                                                <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true" data-toggle="tooltip"
                                                          title="Close">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <?php
                                                        $updateStatusList = '';
                                                        $updateStatusList = \Illuminate\Support\Facades\DB::table('customer_status')
                                                            ->where('id', '<>', $details->status)
                                                            ->get();
                                                        ?>

                                                        <?php echo Form::open(['method'=>'post','url'=>'customerUpdateStatus']); ?>

                                                        <input type="hidden" name="customer_id"
                                                               value="<?php echo e($details->id); ?>">
                                                        <div class="form-group">
                                                            <label for="inputName"><?php echo e(trans('Status Name')); ?></label>
                                                            <label class="text-danger">*</label>
                                                            <?php echo Form::select('status_id',$updateStatusList->pluck('name','id'),null,['style' => 'width:100%','class'=>'form-control select2','id'=>'status_id','placeholder'=>'Please Select Status','required']); ?>


                                                            <?php echo $errors->first('name', '<small class="text text-danger">:message</small>'); ?>

                                                        </div>

                                                        <div class="form-group <?php echo e(($errors->has('details'))?'has-error':''); ?>"
                                                             id="follow_up_date" style="display:block;">
                                                            <label for="inputDescription"><?php echo e(trans('Follow Up Date')); ?></label>
                                                            <?php echo e(Form::text('followup_date',null,['placeholder'=>' Followup Date','id'=>'follow_date','autocomplete'=>'off','class' => 'form-control','readonly'])); ?>

                                                            <?php echo $errors->first('followup_date', '<span class="text-danger">:message</span>'); ?>

                                                        </div>
                                                        <div id="product_form" style="display: none">
                                                            <hr>
                                                            <div class="form-group col-md-12">
                                                                <h3 class="text text-primary"
                                                                    style="font-size: 18px; text-align: center"> <?php echo e(trans('Product Add Area')); ?></h3>
                                                            </div>
                                                            <div class="form-group col-md-12">
                                                                <label>Product</label> <label
                                                                        class="text-danger">*</label>
                                                                <div class="select2-blue">
                                                                    <select class="select2" multiple="multiple"
                                                                            data-placeholder="Select Products"
                                                                            name="product_id[]" id="addProduct"
                                                                            style="width: 100%; height: 200px;"
                                                                            autocomplete="off">
                                                                        <?php $__currentLoopData = $productList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option class='form control'
                                                                                    value='<?php echo e($data->id); ?>' <?php echo e(old('product_id') == $data->id ? "selected" :""); ?> >
                                                                                <?php echo e($data->product_name); ?>

                                                                            </option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </div>
                                                            </div>

                                                        </div>
                                                        <hr/>
                                                        <div class="form-group <?php echo e(($errors->has('remarks'))?'has-error':''); ?>">
                                                            <label for="inputDescription"><?php echo e(trans('app.details')); ?></label>
                                                            <?php echo Form::textarea('remarks',null,['class'=>'form-control','placeholder'=>'Enter  Remarks','rows'=>'4','autocomplete'=>'off']); ?>

                                                            <?php echo $errors->first('remarks', '<span class="label label-danger">:message</span>'); ?>

                                                        </div>


                                                        <div class="modal-footer justify-content-center">

                                                            <button type="submit"
                                                                    class="btn btn-success"><?php echo e(trans('app.update')); ?></button>
                                                            &nbsp; &nbsp;
                                                            <button type="button" class="btn btn-danger"
                                                                    data-dismiss="modal">
                                                                <?php echo e(trans('app.cancel')); ?>

                                                            </button>
                                                        </div>
                                                        <?php echo Form::close(); ?>


                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- /.modal-content -->
                                    </div>
                                    <!-- /.modal-dialog -->
                                </div>


                                <hr>

                                <strong><i class="fas fa-calendar mr-1"></i> Created Date</strong>

                                <p class="text-muted">
                                    <?php echo e($details->created_date); ?>

                                    &nbsp;
                                    <small class="badge badge-secondary"> <i class="far fa-clock"></i>
                                        <?php echo e(Carbon\Carbon::parse($details->created_at)->diffForHumans()); ?>

                                    </small>

                                </p>

                                <hr>

                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                    <div class="col-md-9">
                        <div class="card">
                            <div class="card-header p-2">
                                <?php

                                $permission = helperPermissionLink(url('/customer/create'), url('/customer'));

                                $allowEdit = $permission['isEdit'];

                                $allowDelete = $permission['isDelete'];

                                $allowAdd = $permission['isAdd'];
                                ?>

                                <ul class="nav nav-pills">
                                    <li class="nav-item"><a class="nav-link active" href="#status" data-toggle="tab">Status
                                            History</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#product" data-toggle="tab">Purchase
                                            Product</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#payment"
                                                            data-toggle="tab">Payments</a></li>
                                </ul>


                            </div><!-- /.card-header -->
                            <div class="card-body">
                                <div class="tab-content">
                                    <div class="active tab-pane" id="status">
                                        <!-- Post -->
                                        <div class="post">
                                            <table id="example2" class="table table-striped table-bordered table-hover">
                                                <thead>
                                                <tr>
                                                    <th>S.N.</th>
                                                    <th> Status</th>
                                                    <th> Follow Up Date</th>
                                                    <th> Note</th>
                                                    <th> Changed By</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $status_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <th scope=row><?php echo e(($status_history->currentpage()-1) * $status_history->perpage() + $key+1); ?></th>
                                                        <td>
                                                            <?php if($status->status_id == '1'): ?>
                                                                <button class="btn btn-danger btn-xs"><?php echo e(customerStatus($status->status_id)); ?></button>
                                                            <?php elseif($status->status_id == '2'): ?>
                                                                <button class="btn btn-secondary btn-xs"><?php echo e(customerStatus($status->status_id)); ?></button>

                                                            <?php elseif($status->status_id == '3'): ?>
                                                                <button class="btn btn-success btn-xs"><?php echo e(customerStatus($status->status_id)); ?></button>
                                                            <?php elseif($status->status_id == '4'): ?>
                                                                <button class="btn btn-warning btn-xs"><?php echo e(customerStatus($status->status_id)); ?></button>
                                                            <?php elseif($status->status_id == '5'): ?>
                                                                <button class="btn btn-primary btn-xs"><?php echo e(customerStatus($status->status_id)); ?></button>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php
                                                            $followUpDate = \Carbon\Carbon::parse($status->followup_date, 'UTC');
                                                            ?>
                                                            <span><?php echo e($followUpDate->isoFormat('MMM Do YYYY')); ?></span>

                                                        </td>
                                                        <td>
                                                            <?php if($status->remarks !=null): ?>
                                                                <?php echo e($status->remarks); ?>

                                                            <?php else: ?>
                                                                Not Available
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if($status->statusBy->full_name): ?>
                                                                <?php if($status->created_by == \Illuminate\Support\Facades\Auth::user()->id): ?>
                                                                    <button class="btn btn-secondary btn-xs">You
                                                                    </button>
                                                                <?php else: ?>
                                                                    <?php echo e($status->statusBy->full_name); ?>

                                                                <?php endif; ?>
                                                                    &nbsp;  <?php echo e($status->status_date); ?>

                                                                    <small class="badge badge-secondary"> <i class="far fa-clock"></i>
                                                                        <?php echo e(Carbon\Carbon::parse($status->created_at)->diffForHumans()); ?>

                                                                    </small>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>

                                            </table>
                                            <span class="float-right"><?php echo e($status_history->appends(request()->except('page'))->links()); ?>

                                            </span>

                                        </div>
                                        <!-- /.post -->
                                    </div>
                                    <!-- /.tab-pane -->
                                    <div class="tab-pane" id="product">

                                        <!-- Post -->
                                        <div class="post">

                                            <table id="example4" class="table table-striped table-bordered table-hover">
                                                <thead>
                                                <tr>
                                                    <th style="width: 10px;"><?php echo e(trans('app.sn')); ?></th>
                                                    <th> Product</th>
                                                    <th> Purchase Office</th>
                                                    <th> Purchase Date</th>
                                                    <th> Remarks</th>
                                                </tr>
                                                </thead>
                                                <tbody>

                                                <?php $__currentLoopData = $purchased_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <th scope=row><?php echo e(($purchased_products->currentpage()-1) * $purchased_products->perpage() + $key+1); ?></th>
                                                        <td>
                                                            <?php if(isset($data->product->product_name)): ?>
                                                                <?php echo e($data->product->product_name); ?>

                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if(isset($data->office->office_name)): ?>
                                                                <?php echo e($data->office->office_name); ?>

                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php echo e($data->purchase_date); ?>

                                                            &nbsp;
                                                            <small class="badge badge-secondary"> <i class="far fa-clock"></i>
                                                                <?php echo e(Carbon\Carbon::parse($data->created_at)->diffForHumans()); ?>

                                                            </small>
                                                        </td>
                                                        <td>
                                                            <?php if($status->remarks !=null): ?>
                                                                <?php echo e($status->remarks); ?>

                                                            <?php else: ?>
                                                                Not Available
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </tbody>
                                            </table>
                                            <span class="float-right"><?php echo e($purchased_products->appends(request()->except('page'))->links()); ?>

                                            </span>
                                        </div>
                                        <!-- /.post -->

                                    </div>
                                    <!-- /.tab-pane -->

                                    <div class="tab-pane" id="payment">
                                        <!-- Post -->
                                        <div class="post">
                                            <table id="example5" class="table table-striped table-bordered table-hover">
                                                <thead>
                                                <tr>
                                                    <th style="width: 10px">S.N.</th>
                                                    <th>Product</th>
                                                    <th>Payment Method</th>
                                                    <th>Payment Details</th>
                                                    <th>Remarks</th>
                                                </tr>
                                                </thead>
                                                <tbody>

                                                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <th scope=row><?php echo e(($payments->currentpage()-1) * $payments->perpage() + $key+1); ?></th>
                                                        <td>
                                                            <?php echo e($payment->product->product_name); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e($payment->PaymentMethod->method_name); ?>

                                                        </td>
                                                        <td>
                                                            Paid Date: <?php echo e($payment->paid_date); ?><br/>
                                                            Paid Amount: <?php echo e($payment->paid_amount); ?><br/>
                                                        </td>
                                                        <td>
                                                            <?php echo e($payment->remarks); ?>

                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </tbody>
                                            </table>
                                            <span class="float-right"><?php echo e($payments->appends(request()->except('page'))->links()); ?>

                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.tab-content -->
                            </div><!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/crm_setup/resources/views/backend/customer/show.blade.php ENDPATH**/ ?>