<title><?php echo $__env->yieldContent('page_title',trans('app.logs')); ?></title>
<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e(trans('app.logs')); ?></h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>"><?php echo e(trans('app.dashboard')); ?></a>
                            </li>
                            <li class="breadcrumb-item"><a href="#"><?php echo e(trans('app.logs')); ?></a></li>
                            <li class="breadcrumb-item"><?php echo e($page_title); ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <?php echo $__env->make('backend.message.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header" style="text-align:center">
                                <h3 class="card-title"><?php echo e($page_title); ?></h3>
                                <?php if( $request->from_date !=null || $request->to_date !=null): ?>
                                    <strong> Total Login Failed Count : </strong>  <strong
                                            style="font-size: 16px; color: #FF0000;"><?php echo e($totalLogs); ?></strong>
                                <?php endif; ?>
                                <a href="<?php echo e(URL::previous()); ?>" class="float-right" data-toggle="tooltip"
                                   title="Go Back">
                                    <i class="fa fa-arrow-circle-left fa-2x"></i></a>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div id="accordion">
                                        <div class="card-header">
                                            <h4 class="card-title float-right">
                                                <a data-toggle="collapse" data-parent="#accordion" href="#search">
                                                    <i class="fas fa-filter"></i>Filter
                                                </a>
                                            </h4>
                                        </div>
                                        <div id="search" class="panel-collapse collapse  <?php if( $request->from_date !=null || $request->to_date !=null): ?> show <?php endif; ?>">
                                            <table class="table table-responsive p-0" width="100%">
                                                <form
                                                        action="<?php echo e(url('/logs/failLoginLogs')); ?>" autocomplete="off">
                                                    <tr>
                                                        <td>
                                                            <?php echo Form::text('from_date',Request::get('from_date'),['class'=>'form-control','id'=>'from_date','autocomplete'=>'off','width'=>'100%','placeholder'=>
                                                                               trans('app.fromDate'),'readonly']); ?>

                                                        </td>

                                                        <td>
                                                            <?php echo Form::text('to_date',Request::get('to_date'),['class'=>'form-control','id'=>'to_date','autocomplete'=>'off','width'=>'100%','placeholder'
                                                                                =>
                                                                               trans('app.toDate'),'readonly']); ?>

                                                        </td>
                                                        <td>
                                                            <button class="btn btn-primary" type="submit">
                                                                <i class="fa fa-search">
                                                                </i>
                                                                <?php echo e(trans('app.filter')); ?>

                                                            </button> &nbsp; &nbsp;
                                                            <a href="<?php echo e(url('/logs/failLoginLogs')); ?>"
                                                               class="btn btn-default"> <i
                                                                        class="fas  fa-sync-alt"></i> <?php echo e(trans('app.refresh')); ?>

                                                            </a>
                                                            &nbsp;  &nbsp;
                                                            <a class="btn btn-danger" data-toggle="collapse" data-parent="#accordion" href="#search">
                                                                <span aria-hidden="true">&times;</span> Close
                                                            </a>
                                                        </td>
                                                    </tr>

                                                </form>
                                            </table>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.col -->
                            </div>

                        </div>
                        <!-- /.card-header -->
                        <?php if(sizeof($results) > 0 ): ?>
                            <div class="card">
                                <div class="card-body">
                                    <table id="example3" class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th width="20px;">
                                                <?php echo e(trans('app.sn')); ?>

                                            </th>
                                            <th width="200px;">
                                                <?php echo e(trans('User Name')); ?> /
                                                <?php echo e(trans('app.email')); ?>

                                            </th>
                                            <th width="150px;">
                                                <?php echo e(trans('app.ip')); ?>

                                            </th>
                                            <th width="400px;">
                                                <?php echo e(trans('app.device')); ?>

                                            </th>
                                            <th width="150px">
                                                <?php echo e(trans('app.date')); ?>

                                            </th>
                                            <th width="120px"><?php echo e(trans('app.blockStatus')); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row">
                                                    <?php echo e(($results->currentpage()-1) * $results->perpage() + $key+1); ?>

                                                </th>
                                                <td>
                                                    <?php if(\Illuminate\Support\Facades\Auth::user()->id == $data->user_id): ?>
                                                        <strong class="badge badge-secondary">You</strong>
                                                    <?php elseif($data->user_id !=null): ?>
                                                        <?php echo e($data->user_name); ?>

                                                    <?php else: ?>
                                                        <?php echo e($data->user_name); ?>   <strong class="badge badge-info"> Unknown User</strong>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php echo e($data->log_in_ip); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($data->log_in_device); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($data->created_at); ?>


                                                    &nbsp; &nbsp; <span class="badge badge-secondary"> <i
                                                                class="far fa-clock"> </i> <?php echo e(\Carbon\Carbon::parse($data->created_at)->diffForHumans()); ?></span>
                                                </td>
                                                <td class="text-center">
                                                    <?php if($data->login_fail_count == 5): ?>
                                                        <button type="button" class="btn btn-danger btn-xs"
                                                                data-toggle="modal"
                                                                data-target="#blockStatusModal<?php echo e($key); ?>"
                                                                title="Click here update  status">
                                                            <?php echo e(trans('app.yes')); ?>

                                                        </button>

                                                    <?php else: ?>

                                                        <strong
                                                                class="btn btn-secondary btn-xs"> <?php echo e(trans('app.no')); ?>

                                                        </strong>
                                                    <?php endif; ?>
                                                </td>
                                                <!-- block status  modal start -->
                                                <div class="modal fade" id="blockStatusModal<?php echo e($key); ?>">
                                                    <div class="modal-dialog modal-sm">
                                                        <div class="modal-content">
                                                            <div class="modal-header" style="background: #ffc107">
                                                                <h4 class="modal-title"></h4>
                                                                <button type="button" class="close" data-dismiss="modal"
                                                                        aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <?php if($data->user_id !=null): ?>
                                                                <?php echo Form::open(['method' => 'POST', 'class'=>'inline', 'url'=>['users/block_status/'.$data->user_id]]); ?>

                                                            <?php else: ?>
                                                                <?php echo Form::open(['method' => 'POST', 'class'=>'inline', 'url'=>['logs/ip_block/'.$data->id]]); ?>

                                                            <?php endif; ?>
                                                            <div class="modal-body">
                                                                <?php if($data->user_id !=null): ?>
                                                                    <p>Are you sure you want to user unblock?</p>
                                                                <?php else: ?>
                                                                    <p>Are you sure you want to ip address unblock?</p>
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="modal-footer justify-content-center">
                                                                <button type="submit" class="btn btn-primary">Yes
                                                                </button> &nbsp; &nbsp;
                                                                <button type="button" class="btn btn-default"
                                                                        data-dismiss="modal">No
                                                                </button>
                                                            </div>
                                                            <?php echo Form::close(); ?>

                                                        </div>
                                                        <!-- /.modal-content -->
                                                    </div>
                                                    <!-- /.modal-dialog -->
                                                </div>
                                                <!-- /.modal -->

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <span class="float-right"> <?php echo e($results->appends(request()->except('page'))->links()); ?>

                                </span>
                                </div>
                                <!-- /.card-body -->
                            </div>
                        <?php else: ?>
                            <div class="col-md-12" style="padding-top: 10px">
                                <label class="form-control badge badge-info"
                                       style="text-align:  center; font-size: 18px;">
                                    <i class="fas fa-ban"></i> No record found yet !.
                                </label>
                            </div>
                            <!-- /.card -->
                    </div>
                <?php endif; ?>
                <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
        </section>
        <!-- /.container-fluid -->
        <!-- /.content -->
    </div>

    <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/new_success/resources/views/backend/logs/failLogin.blade.php ENDPATH**/ ?>