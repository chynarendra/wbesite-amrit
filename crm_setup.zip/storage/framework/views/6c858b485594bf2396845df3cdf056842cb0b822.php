<footer class="main-footer">
    <strong>Copyright &copy; <?php echo date('Y');?> <a href="<?php echo e(url('/dashboard')); ?>"><?php if(systemSetting()->app_name): ?><?php echo e(systemSetting()->app_name); ?> <?php else: ?> <?php echo e(env('APP_NAME')); ?>  <?php endif; ?> </a>All rights reserved</strong>
    <div class="float-right d-none d-sm-inline-block">
        <b>Developed By: </b> Charles
    </div>
<?php echo $__env->yieldContent('js'); ?>


    <!-- jQuery -->
    <script src="<?php echo e(url('plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(url('plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(url('theme-design/js/adminlte.js')); ?>"></script>
    <!-- overlayScrollbars -->
    <script src="<?php echo e(url('plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>
    <!-- DataTables  & Plugins -->
    <script src="<?php echo e(url('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(url('plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(url('plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(url('plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(url('plugins/jquery-repeater/src/lib.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(url('plugins/jquery-repeater/src/jquery.input.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(url('plugins/jquery-repeater/src/repeater.js')); ?>" type="text/javascript"></script>

    <script src="<?php echo e(url('js/repeater.js')); ?>"></script>
    <!-- Toastr -->
    <script src="<?php echo e(url('plugins/toastr/toastr.min.js')); ?>"></script>
    <!-- Select2 -->
    <script src=<?php echo e(url("plugins/select2/js/select2.full.js")); ?>></script>
    <!-- English Datepicker -->
    <script type="text/javascript"
            src="<?php echo e(asset('plugins/english-datepicker/english-datepicker.min.js')); ?>"></script>
    <script src=<?php echo e(url("plugins/bootstrap-toggle/js/bootstrap-toggle.js")); ?>></script>
    <!-- summernote -->
    <script src="<?php echo e(url('plugins/summernote/summernote-bs4.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/date_converter.js')); ?>"></script>
    <script src="<?php echo e(url('js/custom_app.js')); ?>"></script>

</footer>
<?php /**PATH /var/www/html/crm_setup/resources/views/backend/layouts/footer.blade.php ENDPATH**/ ?>