<title><?php echo $__env->yieldContent('page_title',$page_title); ?></title>
<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">

            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo e(trans('Product')); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>"><?php echo e(trans('app.dashboard')); ?></a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(url($page_url)); ?>"><?php echo e(trans('Product')); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo e(trans('app.edit')); ?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <?php echo $__env->make('backend.message.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
                <div class="col-md-12" id="listing">
                    <div class="card card-default">
                        <div class="card-header with-border">
                            <h3 class="card-title"> <?php echo e(trans('app.edit')); ?></h3>
                            <?php

                            $permission = helperPermissionLink(url($page_url . '/' . 'create'), url($page_url));

                            $allowEdit = $permission['isEdit'];

                            $allowDelete = $permission['isDelete'];

                            $allowAdd = $permission['isAdd'];
                            ?>

                        </div>
                        <div class="card-body">
                            <?php echo Form::model($edits, ['method'=>'put','route'=>[$page_route.'.'.'update',$edits->id],'enctype'=>'multipart/form-data','file'=>true]); ?>

                            <div class="row">
                                <div class="form-group col-md-6 <?php echo e(($errors->has('campaign_id'))?'has-error':''); ?>">
                                    <label>Campaign</label><label class="text-danger">*</label>
                                    <?php echo Form::select('campaign_id',$champaignList->pluck('campaign_name','id'),null,['id' => 'campaignId','style' => 'width:100%','class'=>'form-control select2','placeholder'=>'Please Select Campaign
                                    ']); ?>

                                    <?php echo $errors->first('campaign_id', '<span class="text-danger">:message</span>'); ?>

                                </div>

                                <div class="form-group col-md-6 <?php echo e(($errors->has('product_category_id'))?'has-error':''); ?>">
                                    <label>Category</label><label class="text-danger">*</label>
                                    <?php echo Form::select('product_category_id',$productCategoryList->pluck('name','id'),null,['id' => 'categoryId','style' => 'width:100%','class'=>'form-control select2','placeholder'=>'Please Select Product Category
                                    ']); ?>

                                    <?php echo $errors->first('product_category_id', '<span class="text-danger">:message</span>'); ?>

                                </div>

                                <div class="form-group col-md-6 <?php echo e(($errors->has('product_name'))?'has-error':''); ?>">
                                    <label for="feature">Name</label><label class="text-danger">*</label>
                                    <?php echo e(Form::text('product_name',null,['placeholder'=>'Product Name','class' => 'form-control'])); ?>

                                    <?php echo $errors->first('product_name', '<span class="text-danger">:message</span>'); ?>

                                </div>

                                <div class="form-group col-md-6 <?php echo e(($errors->has('warrenty_in_years'))?'has-error':''); ?>">
                                    <label for="feature"> Warranty In Years</label><label class="text-danger">*</label>
                                    <?php echo e(Form::number('warrenty_in_years',null,['placeholder'=>'Example: 2 years','class' => 'form-control'])); ?>

                                    <?php echo $errors->first('warrenty_in_years', '<span class="text-danger">:message</span>'); ?>

                                </div>

                                <div class="form-group col-md-12 <?php echo e(($errors->has('about_product'))?'has-error':''); ?>">
                                    <label for="feature">Product Details</label>
                                    <?php echo e(Form::textarea('about_product',null,['placeholder'=>'','class' => 'textarea', 'style' => 'width: 100%; height: 34opx; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px; cols: 300;'])); ?>

                                </div>

                                <div class="form-group col-md-12 text-center">
                                    <button type="submit" class="btn btn-success">
                                        <?php echo e(trans('app.update')); ?>

                                    </button>
                                    &nbsp;
                                    <a  class="btn btn-danger" href="<?php echo e(url($page_url)); ?>"><?php echo e(trans('app.cancel')); ?></a>
                                </div>

                            </div>
                            <?php echo e(Form::close()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/crm_setup/resources/views/backend/product/edit.blade.php ENDPATH**/ ?>