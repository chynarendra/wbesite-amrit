<title><?php echo $__env->yieldContent('page_title',$page_title); ?></title>
<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e(trans('app.systemSetting')); ?></h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>"><?php echo e(trans('app.dashboard')); ?></a>
                            </li>
                            <li class="breadcrumb-item"><a href="#"><?php echo e(trans('app.systemSetting')); ?></a></li>
                            <li class="breadcrumb-item"><?php echo e($page_title); ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <?php echo $__env->make('backend.message.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header" style="text-align:right">
                                <h3 class="card-title"><?php echo e($page_title); ?></h3>


                                <?php

                                $permission = helperPermission();

                                $allowEdit = $permission['isEdit'];

                                $allowDelete = $permission['isDelete'];

                                ?>
                                <a href="<?php echo e(URL::previous()); ?>" class="pull-right" data-toggle="tooltip"
                                   title="Go Back">
                                    <i class="fa fa-arrow-circle-left fa-2x"></i></a>
                                <a href="<?php echo e(url($page_url)); ?>" class="pull-right" data-toggle="tooltip"
                                   title="View List">
                                    <i class="fa fa-list fa-2x"></i></a>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example3" class="table table-bordered">
                                    <thead>
                                    <tr>
                                        <th><?php echo e(trans('app.loginTitle')); ?></th>
                                        <th><?php echo e(trans('app.loginCaptcha')); ?></th>
                                        <th><?php echo e(trans('app.loginForgetPassword')); ?></th>
                                        <th><?php echo e(trans('app.loginAttemptLimit')); ?></th>
                                        <th><?php echo e(trans('app.action')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <?php if(isset($result['login_title'])): ?>
                                                    <?php echo e($result['login_title']); ?>

                                                <?php else: ?>
                                                    N/A
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <?php if($result['login_captcha_required'] == '1'): ?>
                                                    <button type="button"
                                                            class="btn btn-success btn-xs"
                                                            data-toggle="modal"
                                                            data-target="#captchaModal"
                                                            title="Click here update  status">
                                                        <?php echo e(trans('app.yes')); ?>

                                                    </button>
                                                <?php elseif($result['login_captcha_required']== '0'): ?>
                                                    <button type="button"
                                                            class="btn btn-danger btn-xs"
                                                            data-toggle="modal"
                                                            data-target="#captchaModal"
                                                            title="Click here update  status">
                                                        <?php echo e(trans('app.no')); ?>

                                                    </button>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <?php if($result['forget_password_required'] == '1'): ?>
                                                    <button type="button"
                                                            class="btn btn-success btn-xs"
                                                            data-toggle="modal"
                                                            data-target="#forgetPasswordModal"
                                                            title="Click here update  status">
                                                        <?php echo e(trans('app.yes')); ?>

                                                    </button>
                                                <?php elseif($result['forget_password_required']== '0'): ?>
                                                    <button type="button"
                                                            class="btn btn-danger btn-xs"
                                                            data-toggle="modal"
                                                            data-target="#forgetPasswordModal"
                                                            title="Click here update  status">
                                                        <?php echo e(trans('app.no')); ?>

                                                    </button>
                                                <?php endif; ?>
                                            </td>

                                            <td>
                                                <?php if(isset($result['login_attempt_limit'])): ?>
                                                    <?php echo e($result['login_attempt_limit']); ?>

                                                    <button type="button" class="btn btn-success btn-xs"
                                                            style="margin: 10px 0 0 10px;"
                                                            data-placement="top"
                                                            data-toggle="modal" data-target="#loginAttemptModal"> Update
                                                    </button>
                                                <?php else: ?>
                                                    N/A
                                                <?php endif; ?>
                                            </td>


                                            <td>
                                                <?php if($allowEdit): ?>
                                                    <button type="button" class="btn btn-info btn-xs"
                                                            data-toggle="modal"
                                                            data-target="#editModal"
                                                            data-placement="top" title="Edit">
                                                        <i class="fas fa-pencil-alt"></i>
                                                    </button>
                                                <?php endif; ?>

                                            </td>
                                        </tr>
                                    </tbody>
                                </table>

                                <div class="modal fade" id="captchaModal">
                                    <div class="modal-dialog modal-sm modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header btn-secondary">
                                                <h4 class="modal-title"></h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <?php echo Form::open(['method' => 'POST', 'class'=>'inline', 'url'=>[$status_url. '/'.$result['id']]]); ?>

                                            <div class="modal-body text-center">
                                                <input type="hidden" name="column_name" value="login_captcha_required">
                                                <?php if($result['login_captcha_required'] == 1): ?>
                                                    <input type="hidden" name="status" value="0">
                                                    <h6>Are you sure you want to
                                                        no ?</h6>
                                                <?php else: ?>
                                                    <input type="hidden" name="status" value="1">
                                                    <h6>Are you sure you want to yes ?</h6>
                                                <?php endif; ?>
                                            </div>
                                            <div class="modal-footer justify-content-center">
                                                <button type="submit"
                                                        class="btn btn-primary">Yes
                                                </button> &nbsp; &nbsp;
                                                <button type="button"
                                                        class="btn btn-default"
                                                        data-dismiss="modal">No
                                                </button>
                                            </div>
                                            <?php echo Form::close(); ?>

                                        </div>
                                    </div>
                                </div>

                                <div class="modal fade" id="forgetPasswordModal">
                                    <div class="modal-dialog modal-sm modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header btn-secondary">
                                                <h4 class="modal-title"></h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <?php echo Form::open(['method' => 'POST', 'class'=>'inline', 'url'=>[$status_url. '/'.$result['id']]]); ?>

                                            <div class="modal-body text-center">
                                                <input type="hidden" name="column_name" value="forget_password_required">
                                                <?php if($result['forget_password_required'] == 1): ?>
                                                    <input type="hidden" name="status" value="0">
                                                    <h6>Are you sure you want to
                                                        no ?</h6>
                                                <?php else: ?>
                                                    <input type="hidden" name="status" value="1">
                                                    <h6>Are you sure you want to yes ?</h6>
                                                <?php endif; ?>
                                            </div>
                                            <div class="modal-footer justify-content-center">
                                                <button type="submit"
                                                        class="btn btn-primary">Yes
                                                </button> &nbsp; &nbsp;
                                                <button type="button"
                                                        class="btn btn-default"
                                                        data-dismiss="modal">No
                                                </button>
                                            </div>
                                            <?php echo Form::close(); ?>

                                        </div>
                                        <!-- /.modal-content -->
                                    </div>
                                </div>

                                <div class="modal fade" id="registerModal">
                                    <div class="modal-dialog modal-sm modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header btn-secondary">
                                                <h4 class="modal-title"></h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <?php echo Form::open(['method' => 'POST', 'class'=>'inline', 'url'=>[$status_url. '/'.$result['id']]]); ?>

                                            <div class="modal-body text-center">
                                                <input type="hidden" name="column_name" value="register_required">
                                                <?php if($result['register_required ']== 1): ?>
                                                    <input type="hidden" name="status" value="0">
                                                    <h6>Are you sure you want to
                                                        no?</h6>
                                                <?php else: ?>
                                                    <input type="hidden" name="status" value="1">
                                                    <h6>Are you sure you want to yes?</h6>
                                                <?php endif; ?>
                                            </div>
                                            <div class="modal-footer justify-content-center">
                                                <button type="submit"
                                                        class="btn btn-primary">Yes
                                                </button> &nbsp; &nbsp;
                                                <button type="button"
                                                        class="btn btn-default"
                                                        data-dismiss="modal">No
                                                </button>
                                            </div>
                                            <?php echo Form::close(); ?>

                                        </div>
                                        <!-- /.modal-content -->
                                    </div>
                                    <!-- /.modal-dialog -->
                                </div>

                                <div class="modal fade" id="loginAttemptModal">
                                    <div class="modal-dialog modal-sm modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header btn-secondary">
                                                <h4 class="modal-title"></h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <?php echo Form::open(['method' => 'POST', 'class'=>'inline', 'url'=>[$status_url. '/'.$result['id']]]); ?>

                                            <div class="modal-body">
                                                <input type="hidden" name="column_name" value="login_attempt_limit">
                                                <div class="row">
                                                    <div class="form-group col-md-12">
                                                        <label><?php echo e(trans('app.loginAttemptLimit')); ?></label> <label
                                                                class="text text-danger"> *</label>
                                                        <input type="number" class="form-control" name="status" value="<?php echo e($result['login_attempt_limit']); ?>" required min="1">
                                                        <?php echo $errors->first('login_attempt_limit', '<span class="text text-danger">:message</span>'); ?>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer justify-content-center">
                                                <button type="submit"
                                                        class="btn btn-success"><?php echo e(trans('app.update')); ?>

                                                </button> &nbsp; &nbsp;
                                            </div>
                                            <?php echo Form::close(); ?>

                                        </div>
                                        <!-- /.modal-content -->
                                    </div>
                                    <!-- /.modal-dialog -->
                                </div>

                                <div class="modal fade" id="imageModal">
                                    <div class="modal-dialog modal-sm modal-dialog-centered">
                                        <div class="modal-content" style="width: 400px">
                                            <div class="modal-header btn-secondary">
                                                <h6 class="modal-title"><label> Change Login Background  Image </label>
                                                </h6>
                                                <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                <span aria-hidden="true" data-toggle="tooltip"
                                                      title="Close">&times;</span>
                                                </button>
                                            </div>
                                            <?php echo Form::open(['method'=>'post','url'=>$file_upload_url.'/'.$result['id'],'enctype'=>'multipart/form-data']); ?>

                                            <div class="modal-body">
                                                <div style="width: 450px; margin:10px 0 0 35px;">
                                                    <input type="hidden" name="column_name" value="login_background_image">
                                                    <input type="hidden" name="file_title" value="<?php echo e($result['login_title']); ?>">
                                                    <label><?php echo e(trans('app.uploadImage')); ?></label> <label
                                                            class="text-danger">*</label> <br>
                                                    <input type="file" name="update_file" required>
                                                    <br>
                                                    <?php if($errors->has('update_file') == null): ?>
                                                        <span class="text text-danger"
                                                              style="font-size: 13px;color: #ff042c;">
                                                                        Upload type should be jpg,jpeg,png
                                                                        & size must be 1 MB .
                                                                    </span>
                                                    <?php endif; ?>
                                                    <?php echo $errors->first('update_file', '
                                                               <span class="badge badge-danger">
                                                                   :message
                                                               </span>
                                                               '); ?>

                                                </div>
                                            </div>
                                            <div class="modal-footer justify-content-center">
                                                <button type="submit"
                                                        class="btn btn-success">  <?php echo e(trans('app.upload')); ?></button>
                                            </div>
                                            <?php echo Form::close(); ?>

                                        </div>
                                    </div>
                                </div>

                                <div class="modal fade" id="imageViewModal">
                                    <div class="modal-dialog  modal-dialog-centered">
                                        <div class="modal-content" style="width: 500px">
                                            <div class="modal-header btn-secondary">
                                                <h6 class="modal-title">
                                                    <label> Uploaded Login Background  Image </label>
                                                </h6>
                                                <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                <span aria-hidden="true" data-toggle="tooltip"
                                                      title="Close">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <iframe src="<?php echo e(asset('/storage/uploads/files/'.$result['login_background_image'])); ?>"
                                                        width="470"   height="350">

                                                </iframe>
                                                <div style="text-align: center">
                                                    <hr>
                                                    <a href="<?php echo e(URL::to('storage/uploads/files/'.$result['login_background_image'])); ?>"

                                                       class="btn  btn-danger" download
                                                       data-toggle="tooltip"
                                                       title="Download File"><i
                                                                class="fa fa-download"></i>
                                                        Download

                                                    </a>
                                                    &nbsp; &nbsp; &nbsp; &nbsp;
                                                    <button type="button"
                                                            class="btn   btn-default"
                                                            data-dismiss="modal"
                                                            data-toggle="tooltip"
                                                            title="Close">
                                                        Close
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- /.modal-content -->
                                    </div>
                                    <!-- /.modal-dialog -->
                                </div>

                                <div class="modal fade" id="deleteFileModal">
                                    <div class="modal-dialog modal-sm modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header btn-secondary">
                                                <h4 class="modal-title"></h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <?php echo Form::model($result,['method'=>'DELETE','route'=>[$page_route.'.'.'destroy',$result['id']]]); ?>

                                            <div class="modal-body">
                                                <input type="hidden" name="column_name" value="login_background_image">
                                                <p>Are you sure you want to
                                                    delete image?</p>
                                            </div>
                                            <div class="modal-footer justify-content-center">
                                                <button type="submit"
                                                        class="btn btn-primary">Yes
                                                </button> &nbsp; &nbsp;
                                                <button type="button"
                                                        class="btn btn-default"
                                                        data-dismiss="modal">No
                                                </button>
                                            </div>
                                            <?php echo Form::close(); ?>

                                        </div>
                                        <!-- /.modal-content -->
                                    </div>
                                    <!-- /.modal-dialog -->
                                </div>

                                <div class="modal fade" id="editModal">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header btn-secondary">
                                                <h4 class="modal-title"><?php echo e(trans('app.edit')); ?></h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true" data-toggle="tooltip" title="Close">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <?php echo Form::model($result,['method'=>'PUT','route'=>[$page_route.'.'.'update',$result['id']],'enctype'=>'multipart/form-data','autocomplete'=>'off']); ?>

                                                <div class="row">
                                                    <div class="form-group col-md-12">
                                                        <label><?php echo e(trans('app.loginTitle')); ?></label> <label
                                                                class="text text-danger"> *</label>
                                                        <?php echo Form::text('login_title',null,['class'=>'form-control','required','min'=>'1']); ?>

                                                        <?php echo $errors->first('login_title', '<span class="text text-danger">:message</span>'); ?>

                                                    </div>
                                                    <div class="form-group col-md-6">
                                                        <label for="status"><?php echo e(trans('app.loginCaptcha')); ?> </label><br>
                                                        <div class="icheck-success d-inline">
                                                            <input type="radio" id="readio1"
                                                                   name="login_captcha_required" value="1"   <?php if($result['login_captcha_required']=='1'): ?> checked <?php endif; ?>>
                                                            <label for="readio1">
                                                                <?php echo e(trans('app.yes')); ?>

                                                            </label>
                                                        </div>
                                                        &nbsp; &nbsp;
                                                        <div class="icheck-success d-inline">
                                                            <input type="radio" id="readio2"
                                                                   name="login_captcha_required"
                                                                   value="0"  <?php if($result['login_captcha_required']=='0'): ?> checked <?php endif; ?>>
                                                            <label for="readio2">
                                                                <?php echo e(trans('app.no')); ?>

                                                            </label>
                                                        </div>

                                                    </div>
                                                    <div class="form-group col-md-6">
                                                        <label for="status"><?php echo e(trans('app.loginForgetPassword')); ?> </label><br>
                                                        <div class="icheck-primary d-inline">
                                                            <input type="radio" id="readio3"
                                                                   name="forget_password_required" value="1"  <?php if($result['forget_password_required']=='1'): ?> checked <?php endif; ?>>
                                                            <label for="readio3">
                                                                <?php echo e(trans('app.yes')); ?>

                                                            </label>
                                                        </div>
                                                        &nbsp; &nbsp;
                                                        <div class="icheck-primary d-inline">
                                                            <input type="radio" id="readio4"
                                                                   name="forget_password_required"
                                                                   value="0" <?php if($result['forget_password_required']=='0'): ?> checked <?php endif; ?>>
                                                            <label for="readio4">
                                                                <?php echo e(trans('app.no')); ?>

                                                            </label>
                                                        </div>

                                                    </div>
                                                    <div class="form-group col-md-6">
                                                        <label for="status"><?php echo e(trans('app.loginRegister')); ?> </label><br>
                                                        <div class="icheck-info d-inline">
                                                            <input type="radio" id="readio5"
                                                                   name="register_required" value="1"  <?php if($result['register_required']=='1'): ?> checked <?php endif; ?>>
                                                            <label for="readio5">
                                                                <?php echo e(trans('app.yes')); ?>

                                                            </label>
                                                        </div>
                                                        &nbsp; &nbsp;
                                                        <div class="icheck-info d-inline">
                                                            <input type="radio" id="readio6"
                                                                   name="register_required"
                                                                   value="0" <?php if($result['register_required']=='0'): ?> checked <?php endif; ?>>
                                                            <label for="readio6">
                                                                <?php echo e(trans('app.no')); ?>

                                                            </label>
                                                        </div>

                                                    </div>
                                                    <div class="form-group col-md-6">
                                                        <label><?php echo e(trans('app.loginAttemptLimit')); ?></label> <label
                                                                class="text text-danger"> *</label>

                                                        <?php echo Form::number('login_attempt_limit',null,['class'=>'form-control','required','min'=>'1']); ?>

                                                        <?php echo $errors->first('login_attempt_limit', '<span class="text text-danger">:message</span>'); ?>

                                                    </div>

                                                    <div class="form-group col-md-6">
                                                        <label for="image"><?php echo e(trans('app.loginBackgroundImage')); ?></label>
                                                        <input type="file" class="form-control-file" name="login_background_image">
                                                        <?php echo $errors->first('login_background_image', '<span class="text text-danger">:message</span>'); ?>


                                                        <?php if($errors->has('login_background_image') == null): ?>
                                                            <span class="text text-danger"
                                                                  style="font-size: 12px;color: #ff042c">
                                                      Note: Upload type should be jpg,jpeg,png  & size less than 1 MB .
                                                 </span>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="form-group col-md-6">
                                                        <label for="status"><?php echo e(trans('app.loginBackgroundImageDisplay')); ?> </label><br>
                                                        <div class="icheck-info d-inline">
                                                            <input type="radio" id="readio7"
                                                                   name="login_background_image_display" value="1"  <?php if($result['login_background_image_display']=='1'): ?> checked <?php endif; ?>>
                                                            <label for="readio7">
                                                                <?php echo e(trans('app.yes')); ?>

                                                            </label>
                                                        </div>
                                                        &nbsp; &nbsp;
                                                        <div class="icheck-info d-inline">
                                                            <input type="radio" id="readio8"
                                                                   name="login_background_image_display"
                                                                   value="0" <?php if($result['login_background_image_display']=='0'): ?> checked <?php endif; ?>>
                                                            <label for="readio8">
                                                                <?php echo e(trans('app.no')); ?>

                                                            </label>
                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="modal-footer justify-content-center">

                                                    <button type="submit"
                                                            class="btn btn-success"><?php echo e(trans('app.update')); ?></button>
                                                    &nbsp; &nbsp; &nbsp; &nbsp;
                                                    <button type="button" class="btn btn-danger"
                                                            data-dismiss="modal">
                                                        <?php echo e(trans('app.cancel')); ?>

                                                    </button>
                                                </div>

                                                <?php echo Form::close(); ?>

                                            </div>
                                        </div>
                                        <!-- /.modal-content -->
                                    </div>
                                    <!-- /.modal-dialog -->
                                </div>

                                <div class="modal fade" id="imageDisplayModal">
                                    <div class="modal-dialog modal-sm modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header btn-secondary">
                                                <h4 class="modal-title"></h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <?php echo Form::open(['method' => 'POST', 'class'=>'inline', 'url'=>[$status_url. '/'.$result['id']]]); ?>

                                            <div class="modal-body text-center">
                                                <input type="hidden" name="column_name" value="login_background_image_display">
                                                <?php if($result['login_background_image_display'] == 1): ?>
                                                    <input type="hidden" name="status" value="0">
                                                    <h6>Are you sure you want to
                                                        hide image ?</h6>
                                                <?php else: ?>
                                                    <input type="hidden" name="status" value="1">
                                                    <h6>Are you sure you want to display image?</h6>
                                                <?php endif; ?>
                                            </div>
                                            <div class="modal-footer justify-content-center">
                                                <button type="submit"
                                                        class="btn btn-primary">Yes
                                                </button> &nbsp; &nbsp;
                                                <button type="button"
                                                        class="btn btn-default"
                                                        data-dismiss="modal">No
                                                </button>
                                            </div>
                                            <?php echo Form::close(); ?>

                                        </div>
                                    </div>
                                </div>

                                <div class="modal fade" id="imageDisplayConditionModal">
                                    <div class="modal-dialog modal-sm modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header btn-secondary">
                                                <h4 class="modal-title"></h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <?php echo Form::open(['method' => 'POST', 'class'=>'inline', 'url'=>[$status_url. '/'.$result['id']]]); ?>

                                            <div class="modal-body text-center">
                                                <input type="hidden" name="column_name" value="background_image_display_condition">
                                                <?php if($result['background_image_display_condition'] == 0): ?>
                                                    <input type="hidden" name="status" value="1">
                                                    <h6>Are you sure you want to display both (Login & Register)</h6>
                                                <?php elseif($result['background_image_display_condition'] == 2): ?>
                                                    <input type="hidden" name="status" value="1">
                                                    <h6>Register  background image already used.
                                                        Are you sure you want to display both (Login & Register) ?
                                                    </h6>
                                                <?php else: ?>
                                                    <input type="hidden" name="status" value="0">
                                                    <h6>Are you sure you want to hide both (Login & Register)
                                                    </h6>
                                                <?php endif; ?>
                                            </div>
                                            <div class="modal-footer justify-content-center">
                                                <button type="submit"
                                                        class="btn btn-primary">Yes
                                                </button> &nbsp; &nbsp;
                                                <button type="button"
                                                        class="btn btn-default"
                                                        data-dismiss="modal">No
                                                </button>
                                            </div>
                                            <?php echo Form::close(); ?>

                                        </div>
                                    </div>
                                </div>

                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->

                        <!-- /.col -->
                    </div>
                </div>
                <!-- /.row -->
            </div>
        </section>
        <!-- /.container-fluid -->
        <!-- /.content -->

    </div>

    <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/crm_setup/resources/views/backend/systemSetting/loginSetting.blade.php ENDPATH**/ ?>