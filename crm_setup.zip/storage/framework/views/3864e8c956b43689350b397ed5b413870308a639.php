<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(url('/dashboard')); ?>" class="brand-link">
        <img src="<?php if(systemSetting()->app_logo !=null): ?><?php echo e(asset('/storage/uploads/files/'.systemSetting()->app_logo)); ?> <?php else: ?> <?php echo e(url('images/logo.png')); ?>   <?php endif; ?>" alt="Admin Logo" class="brand-image img-circle elevation-3"
             style="opacity: .8">
        <span class="brand-text font-weight-light"><?php if(isset(systemSetting()->app_name)): ?><?php echo e(systemSetting()->app_name); ?> <?php else: ?> <?php echo e(env('APP_NAME')); ?>  <?php endif; ?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <?php if(isset(Auth::user()->image)): ?>
                <div class="image">
                    <img src="<?php echo e(asset('/storage/uploads/users/'.Auth::user()->image)); ?>" class="img-circle elevation-2"
                         alt="User Image">
                </div>
            <?php else: ?>
                <div class="image">
                    <img src="<?php echo e(url('/images/dummyUser.gif')); ?>" class="img-circle elevation-2" alt="User Image">
                </div>
            <?php endif; ?>
            <div class="info">
                <a href="<?php echo e(url('my-profile')); ?>" class="d-block"><?php if(isset(Auth::user()->full_name)): ?><?php echo e(Auth::user()->full_name); ?><?php endif; ?></a>
            </div>
        </div>

    <?php
    $firstLevelMenus = App\Repository\Roles\MenuRepository::getMenu($id = 0);
    $secondLevelMenus = App\Repository\Roles\MenuRepository::getMenu($id = session('menuId'));
    $menus = App\Repository\Roles\MenuRepository::getMenus();

    ?>
    <!-- Sidebar Menu -->
        <nav class="mt-2">
            <?php
            //get controller name
            session(['second_menu'=>false]);

            function activeTabHome($controllerName,$parentMenu=0)
            {

                $action = app('request')->route()->getAction();
                $controller = class_basename($action['controller']);

                list($controller, $action) = explode('@', $controller);

                // get menu link
                $menuLink=App\Repository\Roles\MenuRepository::getMenuLink($controller);

                if($menuLink){
                    if($parentMenu!=0 && $menuLink->parent_id==$parentMenu){
                        session(['second_menu'=>true]);
                    }else{
                        session(['second_menu'=>false]);
                    }

                }


                echo ($controllerName == $controller) ? 'active' : null;
            }
            ?>
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="<?php echo e(url('/dashboard')); ?>" class="nav-link <?php activeTabHome('HomeController');?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>
                            Dashboard
                        </p>
                    </a>
                </li>
                <!-- Add icons to the links using the .nav-icon class
                     with font-awesome or any other icon font library -->
                <?php if(count($firstLevelMenus)>0): ?>
                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($menu->parent_id==0): ?>
                            <?php
                            $secondLevelMenus = App\Repository\Roles\MenuRepository::getMenu($menu->id);
                            ?>

                            <?php if(count($secondLevelMenus)>0): ?>

                                <?php

                                $action = app('request')->route()->getAction();
                                $controller = class_basename($action['controller']);

                                list($controller, $action) = explode('@', $controller);
                                // get menu link
                                $menuLink = App\Repository\Roles\MenuRepository::getMenuLink($controller);

                                ?>

                                <li class="nav-item has-treeview <?php

                                if ($menuLink) {

                                    if ($menuLink->parent_id == $menu->id) {
                                        echo ' menu-open';
                                    }else{
                                        echo '';
                                    }
                                }

                                ?> ">

                                    <a href="#" class="nav-link ">
                                        <i class="<?php echo $menu->menu_icon; ?>" aria-hidden="true"></i>
                                        <p>
                                            <?php echo e($menu->menu_name); ?>

                                            <i class="fas fa-angle-left right"></i>
                                        </p>
                                    </a>

                                    <ul class="nav nav-treeview">

                                        <?php $__currentLoopData = $secondLevelMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondLevelMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <li class="nav-item">
                                                <a href="<?php echo e(url("$secondLevelMenu->menu_link")); ?>"
                                                   class="nav-link <?php activeTabHome($secondLevelMenu->menu_controller,$secondLevelMenu->parent_id);?>">
                                                    <i class="<?php echo $secondLevelMenu->menu_icon; ?>" aria-hidden="true"></i>
                                                    <p><?php echo e($secondLevelMenu->menu_name); ?></p>
                                                </a>
                                            </li>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>

                                </li>

                            <?php else: ?>

                                <li class="nav-item">
                                    <a href="<?php echo e(url($menu->menu_link)); ?>"
                                       class="nav-link <?php activeTabHome($menu->menu_controller);?>">
                                        <i class="<?php echo $menu->menu_icon; ?>" aria-hidden="true"></i>
                                        <p>
                                            <?php echo e($menu->menu_name); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside><?php /**PATH /var/www/html/new_success/resources/views/backend/layouts/sidebar.blade.php ENDPATH**/ ?>