    

    <?php $__env->startSection('content'); ?>

        <?php if(Session::has('status')): ?>
            <div class="alert alert-success">
                <i class="fa fa-check" aria-hidden="true"></i>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo e(Session::get('status')); ?>

            </div>
        <?php endif; ?>

        <?php echo Form::open(['method'=>'post','route'=>'password.email','autocomplete'=>'off']); ?>

        <div class="input-group mb-3 <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
            <?php echo Form::email('email',null,['class'=>'form-control','placeholder'=>'Enter Your Email Address','autocomplete'=>'off']); ?>

            <div class="input-group-append">
                <div class="input-group-text">
                    <span class="fas fa-envelope"></span>
                </div>
            </div>
        </div>

        <?php if($errors->has('email')): ?>
            <div class="input-group mb-3" style="margin-top: -13px;">
                <strong style="color: red"><?php echo e($errors->first('email')); ?></strong>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-12">
                <button type="submit" class="btn btn-primary btn-block">Request new password</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

        <p class="mt-3 mb-1">
            <a href="<?php echo e(route('login')); ?>">Return To Login</a>
        </p>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/new_success/resources/views/auth/passwords/email.blade.php ENDPATH**/ ?>