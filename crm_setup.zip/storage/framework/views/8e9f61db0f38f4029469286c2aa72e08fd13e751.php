<title><?php echo $__env->yieldContent('page_title',trans('Permission Denied')); ?></title>
<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <ol class="breadcrumb">
                
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <center><div class="error-page">
                    <h2 class="text-red" style="font-size: 50px;"> 401</h2>
                </div>

                <div class="error-content">
                    <h3 class="text-red"><i class="fa fa-warning"></i> SORRY </h3>
                    <p style="font-size: 20px;">
                       You do not have permission<br>
                        Please contact your administrator ! <br> <br>
                        <a  class="btn btn-danger" href="<?php echo e(URL::previous()); ?>"> <i class="fa fa-arrow-left"> </i> Go Back</a>
                    </p>
                </div>
                <div>
                </div>
            </center>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/new_success/resources/views/401.blade.php ENDPATH**/ ?>