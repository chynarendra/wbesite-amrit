<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(env('APP_NAME')); ?> | Log in </title>
    <link rel="shortcut icon" href="<?php echo e(asset('images/logo.jpg')); ?>">

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- icheck bootstrap -->
    <link rel="stylesheet" href="<?php echo e(url('plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(url('theme-design/css/adminlte.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/style.css')); ?>">

</head>
<body class="hold-transition login-page loginBackground"
      <?php if(\Route::current()->getName() == 'login' && loginBackgroundImage()->image !=null && loginBackgroundImage()->display == 1 && loginBackgroundImage()->condition == 0 ): ?>
      style="background-image: url('<?php echo e(asset('/storage/uploads/files/'.loginBackgroundImage()->image)); ?>');"
      <?php elseif(\Route::current()->getName() == 'register' && registerBackgroundImage()->image !=null && registerBackgroundImage()->display == 1  && registerBackgroundImage()->condition == 0): ?>
      style="background-image: url('<?php echo e(asset('/storage/uploads/files/'.registerBackgroundImage()->image)); ?>');"
      <?php elseif(loginBackgroundImage()->image !=null && loginBackgroundImage()->display == 1 && loginBackgroundImage()->condition == 1): ?>
      style="background-image: url('<?php echo e(asset('/storage/uploads/files/'.loginBackgroundImage()->image)); ?>');"
      <?php elseif(registerBackgroundImage()->image !=null && registerBackgroundImage()->display == 1  && registerBackgroundImage()->condition == 2): ?>
      style="background-image: url('<?php echo e(asset('/storage/uploads/files/'.registerBackgroundImage()->image)); ?>');"
      <?php elseif(\Route::current()->getName() == 'password.request' && registerBackgroundImage()->image !=null && registerBackgroundImage()->display == 1  && registerBackgroundImage()->condition == 0): ?>
      style="background-image: url('<?php echo e(asset('/storage/uploads/files/'.loginBackgroundImage()->image)); ?>');"
        <?php endif; ?>>
<div class="login-box">
    <!-- /.login-logo -->
    <div class="card card-outline card-primary">
        <div class="card-header text-center">
            <a href="<?php echo e(route('login')); ?>" style="color: red"
               class="h3"><?php if(isset(systemSetting()->app_name)): ?><?php echo e(systemSetting()->app_name); ?> <?php else: ?> <?php echo e(env('APP_NAME')); ?>  <?php endif; ?></a>
        </div>
        <div class="card-body">
            <?php if(\Route::current()->getName() == 'login'): ?>
                <p class="login-box-msg"><?php if(isset(systemSetting()->login_title)): ?><?php echo e(systemSetting()->login_title); ?> <?php endif; ?> </p>
            <?php elseif(\Route::current()->getName() == 'register'): ?>
                <p class="login-box-msg"><?php if(isset(systemSetting()->register_title)): ?><?php echo e(systemSetting()->register_title); ?> <?php endif; ?> </p>
            <?php elseif(\Route::current()->getName() == 'password.request'): ?>
                <p class="login-box-msg">You forgot your password? Here you can easily retrieve a new password.</p>

            <?php else: ?>
                <p class="login-box-msg">You are only one step a way from your new password, recover your password
                    now.
                </p>

        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
        <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src="<?php echo e(url('plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(url('plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(url('theme-design/js/adminlte.min.js')); ?>"></script>
<script type="text/javascript">
    $('#reload').click(function () {
        $.ajax({
            type: 'GET',
            url: 'reload-captcha',
            success: function (data) {
                $(".captcha span").html(data.captcha);
            }
        });
    });

</script>
<script>
    $("document").ready(function () {
        setTimeout(function () {
            $("div.alert").remove();
        }, 5000); // 5 secs

    });
</script>
</body>
</html>
<?php /**PATH /var/www/html/laravel_new_cms/resources/views/layouts/app.blade.php ENDPATH**/ ?>