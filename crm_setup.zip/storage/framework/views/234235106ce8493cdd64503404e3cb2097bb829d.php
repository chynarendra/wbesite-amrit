<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<?php echo $__env->make('backend.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('backend.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
    <?php echo $__env->yieldContent('content'); ?>
</div>
</body>

<?php echo $__env->make('backend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('js'); ?>
</html><?php /**PATH /var/www/html/laravel_new_cms/resources/views/backend/layouts/app.blade.php ENDPATH**/ ?>