<?php

namespace App\Models\Configurations;
use Illuminate\Database\Eloquent\Model;

class District extends Model
{
    protected $table = 'district';
}

