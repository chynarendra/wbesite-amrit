<?php

namespace App\Models\API;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AppUser extends Model
{
    protected $dates = ['deleted_at'];
    protected $fillable=['full_name','address','mobile','email','office_id','designation_id','status','register_date','approved_by','approved_by','password'];
}
