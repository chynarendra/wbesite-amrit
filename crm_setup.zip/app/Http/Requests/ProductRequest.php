<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ProductRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        if ($this->method() == 'PUT') {
            $post_id = $this->segment(2);
            $rules = [
                'product_name' => 'required|min:3|max:200|unique:products,product_name,' . $post_id,
                'campaign_id' => 'required',
                'product_category_id' => 'required',
            ];
        } else {
            $rules = [
                'product_name' => 'required|min:3|max:200|unique:products,product_name',
                'campaign_id' => 'required',
                'product_category_id' => 'required',
            ];
        }
        return $rules;
    }
}
