<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\API\AppUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class LoginApiController extends Controller
{
    public function authenticate(Request $request)
    {
        $validator = Validator::make($request->json()->all(), [
            'username' => 'required',
            'password' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json(["status" => false, "status_code" => 422, "message" => $validator->errors()->all()], 422);
        }
        $user = AppUser::where($this->username(), $request->{$this->username()})->first();
        if($user){
            $responsedata = json_decode($user, true);
            return response()->json($responsedata);
        }else {
            return response()->json(['status' => false, "status_code" => 404, 'message' => "Invalid Credentials"], 404);
        }
    }
    /**
     * Check either username or email.
     * @return string
     */
    public function username()
    {
        $identity = request()->get('username');
        $fieldName = filter_var($identity, FILTER_VALIDATE_EMAIL) ? 'email' : 'mobile';
        request()->merge([$fieldName => $identity]);

        return $fieldName;
    }
}
