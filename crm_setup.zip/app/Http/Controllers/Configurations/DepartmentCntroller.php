<?php

namespace App\Http\Controllers\Configurations;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DepartmentCntroller extends Controller
{
    //
}
