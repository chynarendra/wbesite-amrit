<?php

namespace App\Http\Controllers\SytmeSetting;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class FiscalYearMethodCntroller extends Controller
{
    //
}
